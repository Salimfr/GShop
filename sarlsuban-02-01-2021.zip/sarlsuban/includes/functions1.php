<?php
	$db = mysqli_connect("localhost","root","","sarlsuban");
	function getLeftBar()
	{

		echo 
		"
			
  			<div class='sidenav' style='width:200px; margin-left: 0px; margin-top : 0px;'>
    			<ul class='nav navbar-nav side-nav'>
      				
      				<li class='mt-1 btn btn-light promobtn text-left mb-1'  style='width:200px;'>
        				<a href='index.php?dashboard'>
          					<i class='fa fa-star txt-warning mr-1' >
          					</i>
          					Promotions
        				</a>
      				</li>
      				
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'  style='width:200px;'>
        				<a href='index.php?dashboard'>
          					New Arrivals
        				</a>
      				</li>
      
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'  style='width:200px;'>
        				<a href='index.php?dashboard'>
          					All Products
        				</a>
      				</li>
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'   style='width:200px;'>
        				<a href='index.php?dashboard'>
          					Payment Mode
        				</a>
      				</li>

      				<li class='mt-5 btn btn-light promobtn text-left mb-3'   style='width:200px;'>
        				<a href='index.php?dashboard'>
          					Contact Us
        				</a>
      				</li>
  
    			</ul>
  			</div>
    		
		";

	}

?>

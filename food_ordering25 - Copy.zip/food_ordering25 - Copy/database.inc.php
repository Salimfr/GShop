<?php

$con=mysqli_connect('localhost','root','','food-order');
?>
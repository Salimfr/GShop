<?php
	$db1 = mysqli_connect("localhost","root","","alimentationganesh");
	function getPro($input)
	{
		global $con;
		
		if($input == "promotions"){
			$get_product = "select * from products where s_id = '1' order by 1 ASC ";
			$get_detail = "Promotions";
		}
		elseif($input == "nouveautes"){
			$get_product = "select * from products where s_id = '2' order by 1 ASC ";
			$get_detail = "Nouveautés";
		}
		else
		{
			$get_cat = "select * from categories where cat_title = '$input' order by 1 ASC ";
			$run_cat = mysqli_query($con, $get_cat);
			$row_cat = mysqli_fetch_array($run_cat);
			$cat_id = $row_cat['cat_id'];
			$get_product = "select * from products where c_id = '$cat_id' order by 1 ASC ";
		

		}
		



		$run_products = mysqli_query($con, $get_product);
		while ($row_product = mysqli_fetch_array($run_products))
		{
			$pro_id = $row_product['product_id'];
			$c_id = $row_product['c_id'];
			$pro_name = $row_product['product_name'];
			$pro_price = $row_product['product_price'];
			$pro_img1 = $row_product['product_image'];
			$pro_desc = $row_product['product_desc'];
			$pro_stat = $row_product['s_id'];
            $pro_detail = $row_product['product_detail'];
                 
			echo 
			"
                <div class='card mx-auto mb-4 productcards' id='cardid'>
					<img class='card-img-top cardimg' src='admin_area/product_images/check/$pro_img1'  alt='Card image cap'>
					<div class='card-body d-flex flex-column'>
						<p class='card-title text-center productname mt-md-1'>
							$pro_name
						</p>
						<div class='row pt-md-2 mt-auto'>
							<div class='col-md-6 order-sm-12' >
								<a class='card-text text-md-right pricetext'>
									<b>€ $pro_price</b> / $pro_desc
								</a>
							</div>

                        </div>
					</div>
				</div>
			";
		}
	}

?>

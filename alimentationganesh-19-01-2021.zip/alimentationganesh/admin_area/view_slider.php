<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>

<div class="row">
<div class="col-lg-12">
<div class="panel panel-default mt-3">
<div class="panel-heading">
<h3 class="panel-title">
<i class="fa fa-money fa-fw"></i>
<a class="btn btn-primary" href="admin.php?insert_slider">
Ajouter un Slider
</a>
</h3>	
</div>	

<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-bordered table-hover table-striped">
							<thead>
								<tr>
									<th>
										Id
									</th>
									<th>
										Image
									</th>
									<th>
										Supprimer
									</th>
									<th>
										Modifier
									</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$i=0;
									$get_slides="select * from slider";
									$run_slides=mysqli_query($con, $get_slides);
									while($row_slides=mysqli_fetch_array($run_slides))
									{
										$slide_id=$row_slides['id'];

										$slide_image=$row_slides['slider_image'];	
										$i++;

								?>
									
										<tr>
											<td>
											<?php echo $i ?></td>

										
											<td><img src="slider_images/<?php echo $slide_image; ?>" class="img-responsive" width="100" height="24"></td>


											
												
											
																						

											<td>
												<a class="btn btn-outline-danger "  href="admin.php?delete_product=<?php echo $pro_id ?>">
													<i class="fa fa-trash-o"></i>
													Supprimer
												</a>
											</td>
											<td>
												<a class="btn btn-outline-info "  href="admin.php?edit_slide=<?php echo $pro_id ?>">
													<i class="fa fa-pencil"></i>
													Modifier
												</a>
											</td>
										</tr>
										<?php } ?>
							</tbody>
						</table>	
					</div>
				</div>


<?php } ?>

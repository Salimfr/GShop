<?php
	session_start();
	include("includes/db.php");
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>

<?php
	$admin_session = $_SESSION['admin_email'];
	$get_admin = "select * from admins where admin_email = '$admin_session' ";
	$run_admin = mysqli_query($con, $get_admin);
	$row_admin = mysqli_fetch_array($run_admin);
	$admin_id = $row_admin['admin_id'];
	$admin_name = $row_admin['admin_name'];
	$admin_email = $row_admin['admin_email'];
	$admin_image = $row_admin['admin_image'];
	$admin_country = $row_admin['admin_country'];
	$admin_job = $row_admin['admin_job'];
	$admin_contact = $row_admin['admin_contact'];
	$admin_about = $row_admin['admin_about'];
	$get_pro = "select * from products";
	$run_pro = mysqli_query($con, $get_pro);
	$count_pro = mysqli_num_rows($run_pro);

	

	

	

	$get_cat = "select * from categories";
	$run_cat = mysqli_query($con, $get_cat);
	$count_cat = mysqli_num_rows($run_cat);

	$get_slider = "select * from slider";
	$run_slider = mysqli_query($con, $get_slider);
	$count_slider = mysqli_num_rows($run_slider);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Sarl Suban</title>
  </head>
  <body>

			<?php include 'topbar.php'; ?>

		<div class="row"></div>
			<div class="col-sm-12">
				<?php
					if(isset($_GET['dashboard']))
					{
						include 'dashboard.php';
					}
					if(isset($_GET['insert_product']))
					{
						include 'insert_product.php';
					}
					if(isset($_GET['view_product']))
					{
						include 'view_product.php';
					}
					if(isset($_GET['delete_product']))
					{
						include 'delete_product.php';
					}
					if(isset($_GET['edit_product']))
					{
						include 'edit_product.php';
					}
					if(isset($_GET['active_product']))
					{
						include 'active_product.php';
					}
                                        if(isset($_GET['deactive_product']))
					{
						include 'deactive_product.php';
					}
					if(isset($_GET['insert_categories']))
					{
						include 'insert_cat.php';
					}
					if(isset($_GET['view_categories']))
					{
						include 'view_cat.php';
					}
					if(isset($_GET['delete_cat']))
					{
						include 'delete_cat.php';
					}
					if(isset($_GET['edit_cat']))
					{
						include 'edit_cat.php';
					}
					if(isset($_GET['insert_slider']))
					{
						include 'insert_slider.php';
					}
					if(isset($_GET['view_slider']))
					{
						include 'view_slider.php';
					}
					if(isset($_GET['delete_slide']))
					{
						include 'delete_slider.php';
					}
					if(isset($_GET['edit_slide']))
					{
						include 'edit_slider.php';
					}
					if(isset($_GET['view_customer']))
					{
						include 'view_customer.php';
					}
					if(isset($_GET['customer_delete']))
					{
						include 'customer_delete.php';
					}
					if(isset($_GET['view_order']))
					{
						include 'view_order.php';
					}
					if(isset($_GET['order_delete']))
					{
						include 'order_delete.php';
					}
					if(isset($_GET['view_payments']))
					{
						include 'view_payments.php';
					}
					if(isset($_GET['payment_delete']))
					{
						include 'payment_delete.php';
					}
					if(isset($_GET['insert_user']))
					{
						include 'insert_user.php';
					}
					if(isset($_GET['view_user']))
					{
						include 'view_user.php';
					}
					if(isset($_GET['user_delete']))
					{
						include 'user_delete.php';
					}
					if(isset($_GET['user_profile']))
					{
						include 'user_profile.php';
					}
				?>
			</div>
		</div>
	</div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
<?php } ?>
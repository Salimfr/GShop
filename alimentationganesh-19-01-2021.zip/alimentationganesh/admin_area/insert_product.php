<?php


	include("includes/db.php");
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>
		<!DOCTYPE html>
		<html>
			<head>
				<title>
					Insert Product
				</title>
				<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  				<script>tinymc.init({selector:'textarea'});
				</script>
			</head>
			<body>


				<div class="row pt-3">
					<div class="col-lg-10">
						<div class="panel panel-default pt-3">
							<div class="panel-heading">
								<h3 panel-title>
									<i class="fa a-money fa-w"></i>
									Ajouter un Produit
								</h3>
							</div>
							<div class="panel-body">
								<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Nom de Produit 
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_title" class="form-control" required="">
										</div>
									</div>
					
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Catégorie
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="cat" class="form-control"   style="text-align: left">
												<option>Choisir une catégorie</option>
												<?php
													$get_cats = "select * from categories";
													$run_cats = mysqli_query($con, $get_cats);
													while($row = mysqli_fetch_array($run_cats))
													{
														$id = $row['cat_id'];
														$cat_title = $row['cat_title'];
														echo "<option value = '$id' > $cat_title  </option>";
													}
												?>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Type de Produit
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="status" class="form-control"   style="text-align: left">
												<option>Choisir le type</option>
												<?php
													$get_status = "select * from status";
													$run_status = mysqli_query($con, $get_status);
													while($row = mysqli_fetch_array($run_status))
													{
														$id = $row['id'];
														$status_title = $row['title'];
														echo "<option value = '$id' > $status_title  </option>";
													}
												?>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Ajouter une image
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="file" name="product_image" class="form-control" required="">
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Prix
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_price" class="form-control" required="">
										</div>
									</div>

					
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Type de Quantité (ex : kg / paquet / litre)
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_desc" class="form-control" required="">
										</div>
									</div>

									<div class="form-group">
										<input type="submit" name="submit" value="Ajouter le produit" class=" btn-primary form-control">
									</div>

								</form>
							</div>
						</div>
					</div>
				</div>
			</body>
		</html>


<?php
	if(isset($_POST['submit']))
	{
		$product_title = $_POST['product_title'];
		$cat = $_POST['cat'];
		$status = $_POST['status'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		$product_detail = $_POST['status'];

		$product_image = $_FILES['product_image']['name'];
		$temp_name = $_FILES['product_image']['tmp_name'];

		move_uploaded_file($temp_name, "product_images/check/$product_image");

		$inset_product = "insert into products(c_id, s_id, product_name, product_price, product_desc, product_detail,  product_image) values ('$cat', '$status', '$product_title', '$product_price', '$product_desc', '1', '$product_image')";

		$run_product = mysqli_query($con, $inset_product);

		if($run_product)
		{
			echo "<script>alert('Product Inserted Successfully')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
		else
		{
			echo "<script>alert('Product Not Inserted')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
	}
?>

<?php } ?>
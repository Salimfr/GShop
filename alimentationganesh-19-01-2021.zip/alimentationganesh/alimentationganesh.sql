-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  fdb29.awardspace.net
-- Généré le :  Lun 18 Janvier 2021 à 12:29
-- Version du serveur :  5.7.20-log
-- Version de PHP :  5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `3704116_sarlsuban`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(100) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_country` text NOT NULL,
  `admin_job` varchar(255) NOT NULL,
  `admin_about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_contact`, `admin_country`, `admin_job`, `admin_about`) VALUES
(1, 'Abdul Salim', 'salimfr1975@yahoo.fr', '123456', '', '0033-6-99822496', 'France', 'ceo', 'Web Developer	'),
(6, 'admin', 'admin@yahoo.fr', '123456', '', '', 'France', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Vegetables'),
(2, 'Fruits'),
(3, 'Surgeles'),
(4, 'Riz');

-- --------------------------------------------------------

--
-- Structure de la table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(100) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(4, 'ABDUL SALIM ABDUL WAHAB', 'abc@yahoo.fr', '123456', 'France', 'Corbeil Essonnes', '0699822496', '8 rue Henri Matisse', 'drawing6.jpg', '::1');

-- --------------------------------------------------------

--
-- Structure de la table `customer_order`
--

CREATE TABLE `customer_order` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `product_id` int(100) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `customer_order`
--

INSERT INTO `customer_order` (`order_id`, `customer_id`, `product_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(70, 3, 0, 100, 729146385, 4, 'Large', '2020-12-24 06:10:43', 'Complete'),
(71, 3, 0, 125, 1753341646, 5, 'Extra Large', '2020-12-24 06:17:33', 'Complete'),
(72, 3, 27, 25, 2025162374, 1, 'Select a size', '2020-12-27 17:10:14', 'Complete'),
(73, 4, 27, 6, 1490393655, 2, 'Small', '2020-12-27 16:47:23', 'Complete');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `c_id` int(100) NOT NULL,
  `s_id` int(10) NOT NULL,
  `product_name` text NOT NULL,
  `product_price` text NOT NULL,
  `product_desc` text NOT NULL,
  `product_detail` text NOT NULL,
  `product_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `products`
--

INSERT INTO `products` (`product_id`, `c_id`, `s_id`, `product_name`, `product_price`, `product_desc`, `product_detail`, `product_image`) VALUES
(39, 1, 2, 'Gombo Indien', '7,90', 'kgs', '1', 'gombo-indien.jpg'),
(40, 1, 2, 'Haricot Plat', '7,90', 'kgs', '1', 'haricot-plat.jpg'),
(41, 1, 2, 'Karela', '5,90', 'kgs', '1', 'karela.jpg'),
(43, 1, 2, 'CacahuÃ¨te', '4,90', 'kgs', '1', 'CacahuÃ¨te.jpg'),
(44, 1, 2, 'Oignon rouge petit Inde', '6,90', 'kgs', '1', 'ongnion.jpg'),
(45, 1, 2, 'Feuille de Vettale', '19,90', 'kgs', '1', 'Feuille-de-Vettale.jpg'),
(46, 1, 2, 'Petite courgette Inde', '7,90', 'kgs', '1', 'Petite-courgette-Inde.jpg'),
(47, 1, 2, 'Piment indien', '6,90', 'kgs', '1', 'Piment-indien.jpg'),
(48, 1, 2, 'Feuille de basilique', '6,90', 'kgs', '1', 'Feuille-de-basilique.jpg'),
(49, 1, 2, 'Cive', '1,50', 'piÃ¨ce', '1', 'Cive.jpg'),
(50, 1, 2, 'Noix', '3,90', 'kgs', '1', 'Noix.jpg'),
(51, 1, 2, 'Haricot long', '7,90', 'kgs', '1', 'Haricot-long.jpg'),
(52, 1, 2, 'Gingembre', '4,90', 'kgs', '1', 'Gingembre.jpg'),
(53, 1, 2, 'Ail sachet', '2,50', '500g', '1', 'Ail-sachet.jpg'),
(54, 1, 2, 'Ail violet', '4,90', 'kgs', '1', 'Ail-violet.jpg'),
(55, 1, 2, 'Feuille de moringa', '9,90', 'kgs', '1', 'Feuille-de-moringa.jpg'),
(56, 1, 2, 'Fleur dâ€™oignon', '9,90', 'kgs', '1', 'fleur.jpg'),
(57, 1, 2, 'Chayote / christophine', '3,90', 'kgs', '1', 'Chayote-christophine.jpg'),
(58, 2, 2, 'Banane indien', '7,90', 'kgs', '1', 'Banane-indien.jpg'),
(59, 1, 2, 'Fleur de banane', '7,90', 'kgs', '1', 'Fleur-de-banane.jpg'),
(60, 1, 2, 'Curcuma frais', '9,90', 'kgs', '1', 'Curcuma-frais.jpg'),
(61, 1, 2, 'Banane indien bateau', '7,90', 'kgs', '1', 'Banane-indien-bateau.jpg'),
(62, 1, 2, 'Aubergine', '4,90', 'kgs', '1', 'Aubergine.jpg'),
(63, 1, 2, 'Aubergine 2', '4,90', 'kgs', '1', 'Aubergine2.jpg'),
(64, 1, 2, 'Aubergine vert', '5,90', 'kgs', '1', 'Aubergine-vert.jpg'),
(65, 1, 2, 'Menthe frais', '0,40', 'piÃ¨ce', '1', 'Menthe-frais.jpg'),
(66, 1, 2, 'Aubergine long Sri Lanka', '4,90', 'kgs', '1', 'Aubergine-long-Sri-Lanka.jpg'),
(67, 1, 2, 'Pudhale', '7,90', 'kgs', '1', 'Pudhale.jpg'),
(68, 1, 2, 'Woodapple', '6,90', 'kgs', '1', 'Woodapple.jpg'),
(69, 1, 2, 'Rassavali', '6,90', 'kgs', '1', 'Rassavali.jpg'),
(70, 1, 2, 'Mangue verte', '4,90', 'kgs', '1', 'Mangue-verte.jpg'),
(71, 1, 2, 'Canne Ã  sucre', '4,90', 'kgs', '1', 'Canne-Ã -sucre.jpg'),
(72, 1, 2, 'Ã‰pinard', '7,90', 'kgs', '1', 'Ã‰pinard.jpg'),
(73, 1, 2, 'Radis long', '3,90', 'kgs', '1', 'Radis-long.jpg'),
(74, 1, 2, 'Courgette indien', '5,90', 'kgs', '1', 'Courgette-indien.jpg'),
(75, 1, 2, 'Taro Inde', '5,90', 'kgs', '1', 'Taro-Inde.jpg'),
(76, 1, 2, 'patate de palme', '6,90', 'kgs', '1', 'patate-de-palme.jpg'),
(77, 1, 2, 'Feuille Curcuma', '12,90', 'kgs', '1', 'Feuille-Curcuma.jpg'),
(78, 2, 2, 'Amla fruit', '7,90', 'kgs', '1', 'Amla-fruit.jpg'),
(79, 1, 2, 'Gombo', '7,90', 'kgs', '1', 'gombo.jpg'),
(80, 1, 2, 'Papai', '4,90', 'kgs', '1', 'papai.jpg'),
(81, 2, 2, 'Citron Jaune', '3,90', 'kgs', '1', 'citron-jaune.jpg'),
(82, 2, 2, 'Citron Vert', '4,90', 'kgs', '1', 'citron-vert.jpg'),
(83, 1, 2, 'Poivron Rouge', '2,90', 'kgs', '1', 'poivron-rouge.jpg'),
(84, 1, 2, 'Poivron Vert', '2,90', 'kgs', '1', 'poivron-vert.jpg'),
(85, 1, 2, 'Concombre', '1,30', 'piÃ¨ce', '1', 'concombre.jpg'),
(86, 1, 2, 'Courgette', '2,90', 'kgs', '1', 'courgette.jpg'),
(87, 1, 2, 'Aubergine France', '2,90', 'kgs', '1', 'aubergine-france.jpg'),
(88, 1, 2, 'Carotte', '1,90', 'kgs', '1', 'carotte.jpg'),
(89, 1, 2, 'Taro Petit', '4,90', 'kgs', '1', 'taro-petit.jpg'),
(90, 1, 2, 'Ignam', '2,90', 'kgs', '1', 'ignam.jpg'),
(91, 1, 2, 'Banana Petit Vert', '1,50', 'kgs', '1', 'banana-petit-vert.jpg'),
(92, 1, 2, 'Plantain Vert', '1,50', 'kgs', '1', 'plantain-vert.jpg'),
(93, 1, 2, 'Tomate', '1,90', 'kgs', '1', 'tomate.jpg'),
(94, 1, 2, 'Echalote', '3,90', 'kgs', '1', 'echalote.jpg'),
(95, 1, 2, 'Manioc', '1,90', 'kgs', '1', 'manioc.jpg'),
(96, 1, 2, 'Potote Douce Violette', '2,50', 'kgs', '1', 'potote-douce-violette.jpg'),
(97, 1, 2, 'Potote Douce Jaune', '2,50', 'kgs', '1', 'potote-douce-jaune.jpg'),
(98, 0, 0, 'Potote Douce Blanc', '3,90', 'kgs', '1', 'potote-douce-blanc.jpg'),
(99, 2, 2, 'Goyave', '6,90', 'kgs', '1', 'goyave.jpg'),
(100, 1, 2, 'Chou Fleur', '1,50', 'kgs', '1', 'chou-fleur.jpg'),
(101, 1, 2, 'Salade', '1', 'piÃ¨ce', '1', 'salade.jpg'),
(102, 1, 2, 'Dachine', '6,90', 'kgs', '1', 'dachine.jpg'),
(103, 1, 2, 'Poireau', '2,90', 'kgs', '1', 'poireau.jpg'),
(104, 2, 2, 'Kaki', '2,90', 'kgs', '1', 'kaki.jpg'),
(105, 2, 2, 'Kiwi', '3,90', 'kgs', '1', 'kiwi.jpg'),
(106, 2, 0, 'Poire', '2,90', 'kgs', '1', 'poire.jpg'),
(107, 2, 2, 'Clementine', '3,90', 'kgs', '1', 'clementine.jpg'),
(108, 2, 2, 'Orange', '2,90', 'kgs', '1', 'orange.jpg'),
(116, 1, 2, 'Feuille de Banane', '1', 'piece ', '1', 'IMG_3473.JPG'),
(132, 4, 2, 'Heer Riz 1 kg.', '3,95', 'kgs', '1', 'heer-rice-1kg.jpg'),
(133, 4, 2, 'Heer Riz 2 Kgs.', '7,95', '2 kgs.', '1', 'heer-rice-2kg.jpg'),
(134, 4, 2, 'Heer Riz 5 Kgs.', '15,90', '5 kgs', '1', 'heer-rice-5kg.jpg'),
(135, 4, 2, 'Heer Riz 10 Kgs.', '25,90', '10 Kgs.', '1', 'heer-rice-10kg.jpg'),
(136, 4, 2, 'Heer Riz 20 Kgs.', '39,90', '20 Kgs.', '1', 'heer-rice-20kg.jpg'),
(137, 4, 2, 'Akash Riz 1 Kg.', '2,95', 'Kg.', '1', 'akash-rice-1kg.jpg'),
(138, 4, 2, 'Akash Riz 2 Kgs.', '6,95', '2 Kgs.', '1', 'akash-rice-2kg.jpg'),
(139, 4, 2, 'Akash Riz 5 Kgs.', '10,90', '5 Kgs', '1', 'akash-rice-5kg.jpg'),
(140, 4, 2, 'Akash Riz 10 Kgs.', '19,90', '10 Kgs.', '1', 'akash-rice-10kg.jpg'),
(141, 4, 2, 'Akash Riz 20 Kgs.', '35,90', '20 Kgs.', '1', 'akash-rice-20kg.jpg'),
(143, 4, 2, 'Tilda Gold Fragant Jasmine 1 Kg.', '1,75', 'Kg.', '1', 'tilda-rice-1kg.jpg'),
(144, 4, 2, 'Veetee Rice 1 Kg.', '3,95', 'Kg.', '1', 'veetee-rice-1kg.jpg'),
(145, 4, 2, 'Veetee Rice 2 Kgs.', '7,95', '2 Kgs.', '1', 'veetee-rice-2kg.jpg'),
(146, 4, 2, 'Veetee Mega Riz 5 Kgs.', '14,90', '5 Kgs.', '1', 'veetee-mega-rice-5kg.jpg'),
(147, 4, 2, 'Veetee Mega Riz 10 Kgs.', '27,90', '10 Kgs.', '1', 'veetee-mega=rice-10kg.jpg'),
(149, 4, 2, 'Shama Riz Extra Long 5 Kgs.', '15,90', '5 Kgs.', '1', 'shama-rice-5kg.jpg'),
(150, 4, 2, 'Shama Riz Extra Long 10 Kgs.', '25,90', '10 Kgs.', '1', 'shama-riz-10kg.jpg'),
(151, 4, 2, 'Shama Riz Extra Long 20 Kgs.', '39,90', '20 Kgs.', '1', 'shama-rice-20kg.jpg'),
(152, 4, 2, 'Shama Golden Sella Riz 1 Kg.', '2,95', 'Kg.', '1', 'shama-golden-sella-rice-1kg.jpg'),
(153, 4, 2, 'Shama Golden Sella Riz 5 Kgs.', '14,90', '5 Kgs.', '1', 'shama-rice-5kg.jpg'),
(154, 4, 2, 'Shama Golden Sella Riz 20 Kgs.', '39,90', '20 Kgs.', '1', 'shama-golden-sella-rice-20kg.jpg'),
(155, 4, 2, 'Kalyani Thanjavur Ponni Riz 20 Kgs.', '29,90', '20 Kgs.', '1', 'kalyani-rice.jpg'),
(156, 4, 2, 'Veetee Broken Basmati Riz 20 Kgs.', '14,90', '20 Kgs.', '1', 'veetee-broken-rice-20kg.jpg'),
(157, 4, 2, 'Tilda Broken Riz 20 Kgs.', '35,90', '20 Kgs.', '1', 'tilda-broken-basmati-rice-20kg.jpg'),
(158, 4, 2, 'Laila Basmati Riz 20 Kgs.', '35,90', '20 Kgs.', '1', 'laila-basmati-rice-20kg.jpg'),
(159, 4, 2, 'Devaaya Basmati Riz 20 Kgs.', '37,90', '20 Kgs.', '1', 'devaaya-basmati-rice-20kg.jpg'),
(160, 4, 2, 'Tilda Grand Extra Long 20 Kgs.', '42,90', '20 Kgs.', '1', 'tilda-grand-extra-long-rice-20kg.jpg'),
(161, 4, 2, 'Dawaat Extra Long Vert Riz 20 Kgs.', '37,90', '20 Kgs.', '1', 'dawaat-extra-long-vert-rice-20kg.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `product_category`
--

CREATE TABLE `product_category` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `product_category`
--

INSERT INTO `product_category` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(8, 'Bags', ''),
(9, 'Clothes', '');

-- --------------------------------------------------------

--
-- Structure de la table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `slider_name` text NOT NULL,
  `slider_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `slider`
--

INSERT INTO `slider` (`id`, `slider_name`, `slider_image`) VALUES
(1, 'slider 1', 'banner2.jpg'),
(2, 'slider 2', 'banner1.jpg'),
(3, 'slider 3', 'banner3.jpg'),
(4, 'slider 4 ', 'banner4.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `status`
--

CREATE TABLE `status` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `status`
--

INSERT INTO `status` (`id`, `title`) VALUES
(1, 'Promotion'),
(2, 'New Arrivals'),
(3, 'Old Stock');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Index pour la table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Index pour la table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Index pour la table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- Index pour la table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;
--
-- AUTO_INCREMENT pour la table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `p_cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
	session_start();
	include("includes/db.php");
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>

<?php
	$admin_session = $_SESSION['admin_email'];
	$get_admin = "select * from admins where admin_email = '$admin_session' ";
	$run_admin = mysqli_query($con, $get_admin);
	$row_admin = mysqli_fetch_array($run_admin);
	$admin_id = $row_admin['admin_id'];
	$admin_name = $row_admin['admin_name'];

	$get_pro = "select * from products";
	$run_pro = mysqli_query($con, $get_pro);
	$count_pro = mysqli_num_rows($run_pro);

	$get_cust = "select * from customers";
	$run_cust = mysqli_query($con, $get_cust);
	$count_cust = mysqli_num_rows($run_cust);

	$get_p_cat = "select * from product_category";
	$run_p_cat = mysqli_query($con, $get_p_cat);
	$count_p_cat = mysqli_num_rows($run_p_cat);

	$get_p_cat = "select * from customer_order";
	$run_order = mysqli_query($con, $get_p_cat);
	$count_order = mysqli_num_rows($run_order);

?>



<!DOCTYPE html>
<html>
<head>
	<title>Bien Achat</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
		
	</script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body>
	<div id="wrapper" class="col-lg-12">
		<div class="col-md-3">
			<?php include 'includes/sidebar.php'; ?>
		</div>
		<div class="col-md-9">
			<?php
					if(isset($_GET['dashboard']))
					{
						include 'dashboard.php';
					}
				?>
		</div>
	</div>




<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php } ?>
<?php

	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{


?>

<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Dashboard
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-dashboard"></i>
				Dashboard
			</li>
		</ol>
	</div>
</div>
<div class="row">
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-primary">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-tasks fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge" style="font-size: 40px; line-height: normal">
							12
						</div>
						<div>
							Products
						</div>
					</div>
				</div>	
			</div>
			<a href="index.php?view_product">
				<div class="panel-footer">.
					<span class="pull-left">
						View Details
					</span>
					<span class="pull-right">
						<i class="fa fa-arrow-circle-right">
						</i>
					</span>
					<div class="clearfx">
						
					</div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-green" style = "color: #fff; background-color: #5cd85c">
			<div class="panel-heading"  style = "color: #fff; background-color: #5cd85c";>
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-comments fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge" style="font-size: 40px; line-height: normal">
							9
						</div>
						<div>
							Customers
						</div>
					</div>
				</div>	
			</div>
			<a href="index.php?view_product" style="color:#5cd85c">
				<div class="panel-footer">.
					<span class="pull-left">
						View Details
					</span>
					<span class="pull-right">
						<i class="fa fa-arrow-circle-right">
						</i>
					</span>
					<div class="clearfx">
						
					</div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-red"  style = "color: #fff; background-color: #d9534f">
			<div class="panel-heading"  style = "color: #fff; background-color: #d9534f">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-shopping-cart fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge" style="font-size: 40px; line-height: normal">
							14
						</div>
						<div>
							Product Categories
						</div>
					</div>
				</div>	
			</div>
			<a href="index.php?view_product"  style = "color: #d9534f">
				<div class="panel-footer">.
					<span class="pull-left">
						View Details
					</span>
					<span class="pull-right">
						<i class="fa fa-arrow-circle-right">
						</i>
					</span>
					<div class="clearfx">
						
					</div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-yellow"  style = "color: #fff; background-color: #f0ad4e">
			<div class="panel-heading" style = "color: #fff; background-color: #f0ad4e">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-support fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge" style="font-size: 40px; line-height: normal">
							5
						</div>
						<div>
							Orders
						</div>
					</div>
				</div>	
			</div>
			<a href="index.php?view_product"  style = "color: #f0ad4e">
				<div class="panel-footer">.
					<span class="pull-left">
						View Details
					</span>
					<span class="pull-right">
						<i class="fa fa-arrow-circle-right">
						</i>
					</span>
					<div class="clearfx">
						
					</div>
				</div>
			</a>
		</div>
	</div>
</div>

<?php } ?>
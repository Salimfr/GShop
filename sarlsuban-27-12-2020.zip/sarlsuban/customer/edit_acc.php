<?php
	$customer_email=$_SESSION['customer_email'];
	$get_customer = "select * from customers where customer_email='$customer_email'";
	$run_cust = mysqli_query($con, $get_customer);
	$row_cust = mysqli_fetch_array($run_cust);
	$customer_id=$row_cust['customer_id'];
	$customer_name=$row_cust['customer_name'];
	$customer_email=$row_cust['customer_email'];
	$customer_country=$row_cust['customer_country'];
	$customer_city=$row_cust['customer_city'];
	$customer_contact=$row_cust['customer_contact'];
	$customer_address=$row_cust['customer_address'];
	$customer_image=$row_cust['customer_image'];
?>

<div class="box">
	<center>
		<h1>Edit Your Account</h1>
	</center>
	<div class="form-group">
		<label>Customer Name</label>
		<input type="text" name="c_name" class="form-control" value="<?php echo $customer_name ?>" required="">
	</div>
	<div class="form-group">
		<label>Customer Email</label>
		<input type="text" name="c_email" class="form-control" value="<?php echo $customer_email ?>"  required="">
	</div>
	<div class="form-group">
		<label>Customer Password</label>
		<input type="password" name="c_password" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Country</label>
		<input type="text" name="c_country" class="form-control"  value="<?php echo $customer_country ?>" required="">
	</div>
	<div class="form-group">
		<label>Customer City</label>
		<input type="text" name="c_city" class="form-control" value="<?php echo $customer_city ?>"  required="">
	</div>
	<div class="form-group">
		<label>Contact Number</label>
		<input type="text" name="c_number" class="form-control"  value="<?php echo $customer_contact ?>" required="">
	</div>
	<div class="form-group">
		<label>Customer Address</label>
		<input type="text" name="c_address" class="form-control"  value="<?php echo $customer_address ?>" required="">
	</div>
	<div class="form-group">
		<label>Customer Image</label>
		<input type="file" name="c_image" class="form-control" required="">
		<img src="customer_images/product1.jpg" class="img-resposive" height="100px" width="100px">
	</div>
	<div class="text-center">
		<button class="btn btn-primary" name="update">
			Update
		</button>
	</div>
</div>
<div class="box">
	<h1 class="text-center">Payment options</h1>
	<p class="lead text-center">
		<a href="#">Pay offline</a>
	</p>
	<center>
		<p class="lead">
			<a href="#">Pay with paypal
				<br>
				<br>
				<img src = "images/paypal.jpg" width="500" height="270" class="img-responsive"></a>
		</p>
	</center>
</div>
from django.db import  models
from django.core.validators import MinLengthValidator

class Stock(models.Model):
    pno = models.CharField(max_length=50, null=True, blank=True)
    supplier = models.CharField(max_length=50, null=True, blank=True)
    maincategory = models.CharField(max_length=50, null=True, blank=True)
    subcategory = models.CharField(max_length=50, null=True, blank=True)
    subcategory2 = models.CharField(max_length=50, null=True, blank=True)
    product = models.CharField(max_length=50, null=True, blank=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=3, default=0, null=True, blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=3, default=0, null=True, blank=True)
    total = models.DecimalField(max_digits=10, decimal_places=3, default=0, null=True, blank=True)
    posted = models.CharField(max_length=10, null=True, blank=True)



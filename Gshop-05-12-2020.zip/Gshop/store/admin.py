from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order
from .models.ordermain import OrderMain
from .models.supplier import Supplier
from .models.tabletest import Tabletest
from .models.stock import Stock
from .models.supplierorder import SupplierOrder



class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'category', 'maincategory', 'subcategory', 'subcategory2', 'description', 'quantity','image','promotion']



class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


class AdminOrder(admin.ModelAdmin):
    list_display = ['orderno', 'product', 'quantity', 'price',]


class AdminCustomer(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'phone', 'email', 'password']


class AdminOrderMain(admin.ModelAdmin):
    list_display = ['orderno', 'customer', 'address', 'phone', 'date', 'totalamt', 'status']


class AdminSupplier(admin.ModelAdmin):
    list_display = ['name', 'cperson', 'address', 'phone', 'email']


class AdminTableTest(admin.ModelAdmin):
    list_display = ['category1', 'category2', 'category3', 'category4']


class AdminStock(admin.ModelAdmin):
    list_display = ['pno', 'supplier', 'maincategory', 'subcategory', 'subcategory2', 'product', 'quantity', 'price', 'posted', 'total']


class AdminSupplierOrder(admin.ModelAdmin):
    list_display = ['pno', 'name', 'amount', 'received']



# Register your models here.
admin.site.register(Product, AdminProduct)
admin.site.register(Category , AdminCategory)
admin.site.register(Customer, AdminCustomer )
admin.site.register(Order, AdminOrder )
admin.site.register(OrderMain, AdminOrderMain )
admin.site.register(Supplier, AdminSupplier )
admin.site.register(Tabletest, AdminTableTest )
admin.site.register(Stock, AdminStock )
admin.site.register(SupplierOrder, AdminSupplierOrder)

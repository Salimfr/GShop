from django.shortcuts import render , redirect , HttpResponseRedirect

from django.contrib.auth.hashers import  check_password
from store.models.customer import Customer
from django.views import  View
from store.models.forms import ProductForm
from store.models.product import Product
from store.models.category import Category
from store.models.ordermain import OrderMain
from store.models.orders import Order




def cancelorderclient(request, id):
    ordermain = OrderMain.objects.get(orderno=id)
    ordermain.status = "c"
    ordermain.save()
    customer = request.session.get('customer')
    orders = Order.get_orders_by_customer(customer)
    ordermains = OrderMain.get_orders_by_customer(customer)
    return render(request, 'orders.html', {'ordermains': ordermains, 'orders': orders})

def cancelorderadmin(request, id):
    ordermain = OrderMain.objects.get(orderno=id)
    ordermain.status = "c"
    ordermain.save()
    customer = request.session.get('customer')
    orders = Order.get_orders_by_customer(customer)
    ordermains = OrderMain.get_orders_by_customer(customer)
    return render(request, 'adminmain.html', {'ordermains': ordermains, 'orders': orders})

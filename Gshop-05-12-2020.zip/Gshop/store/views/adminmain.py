from django.shortcuts import render , redirect , HttpResponseRedirect

from django.contrib.auth.hashers import  check_password
from store.models.customer import Customer
from django.views import  View
from store.models.forms import ProductForm
from store.models.product import Product
from store.models.category import Category
from store.models.supplier import Supplier
from store.models.ordermain import OrderMain
from store.models.orders import Order
from store.models.tabletest import Tabletest
from store.models.supplierorder import SupplierOrder




def adminmain(request):
    category = Category.objects.all()
    product = Product.objects.all()
    orders = Order.objects.all()
    ordermain = OrderMain.objects.all()
    supplierorders = SupplierOrder.objects.all()

    categoryfield1 = Tabletest.objects.values('category1').distinct()
    categoryfield2 = Tabletest.objects.values('category1', 'category2').distinct()
    categoryfield3 = Tabletest.objects.values('category2', 'category3').distinct()
    categoryfield4 = Tabletest.objects.values('category3', 'category4').distinct()

    data = {}
    data['products'] = product
    data['categories'] = category
    data['orders'] = orders
    data['ordermain'] = ordermain
    data['supplierorders'] = supplierorders
    data['categoryfield1'] = categoryfield1
    data['categoryfield2'] = categoryfield2
    data['categoryfield3'] = categoryfield3
    data['categoryfield4'] = categoryfield4

    return render(request, 'adminmain.html', data)






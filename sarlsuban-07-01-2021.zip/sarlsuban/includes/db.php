<?php

$con = mysqli_connect("fdb29.awardspace.net","3704116_sarlsuban","Zishansaheen123@","3704116_sarlsuban");

?>
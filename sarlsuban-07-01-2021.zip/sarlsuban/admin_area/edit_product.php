<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>
<?php
	if(isset($_GET['edit_product']))
	{
		$edit_id = $_GET['edit_product'];
		$get_p = "select * from products where product_id='$edit_id'";
		$run_edit=mysqli_query($con, $get_p);
		$row_edit=mysqli_fetch_array($run_edit);
		$p_id = $row_edit['product_id'];
		$p_title=$row_edit['product_name'];
		$c_id = $row_edit['c_id'];
		$s_id = $row_edit['s_id'];
		$p_image = $row_edit['product_image'];
		$p_desc = $row_edit['product_desc'];
		$p_price = $row_edit['product_price'];
		$get_cat = "select * from categories where cat_id='$c_id'";
		$run_cat = mysqli_query($con, $get_cat);
		$row_cat = mysqli_fetch_array($run_cat);
		$cat_id = $row_cat['cat_id'];
		$cat_title = $row_cat['cat_title'];
		$get_status = "select * from status where id='$s_id'";
		$run_status = mysqli_query($con, $get_status);
		$row_status = mysqli_fetch_array($run_status);
		$status_id = $row_status['id'];
		$status_title = $row_status['title'];
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Edit Product
		</title>
		<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
		<script>tinymc.init({selector:'textarea'});
		</script>
	</head>
	<body>
		<div class="row">
			<div class="col-lg-10">
				<div class="breadcrumb">
					<li class="active">
						<i class="fa fa-dashboard"></i>
						Dashboard / Edit Product
					</li>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-10">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 panel-title>
							<i class="fa a-money fa-w"></i>Edit Product
						</h3>
					</div>
					<div class="panel-body">
						<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
							
							<div class="form-group">
								<label class="col-md-2 control-label " style="text-align: left">
									Name : 
								</label>
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>
								<div class="col-md-9">
									<input type="text" name="product_title" class="form-control" required value="<?php echo $p_title; ?>">
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-2 control-label"  style="text-align: left">
									Category
								</label>
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>
								</label>
								<div class="col-md-9">
									<select name="cat" class="form-control">
										<option value="<?php echo $cat; ?>"><?php echo $cat_title; ?></option>
										<?php
											$get_cats = "select * from categories";
											$run_cats = mysqli_query($con, $get_cats);
											while($row = mysqli_fetch_array($run_cats))
											{
												$id = $row['cat_id'];
												$cat_title = $row['cat_title'];
												echo "<option value='$id' > $cat_title  </option>";
											}
										?>
									</select>
								</div>
							</div>
					

							<div class="form-group">
								<label class="col-md-2 control-label"  style="text-align: left">
									Status
								</label>
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>
								</label>
								<div class="col-md-9">
									<select name="status" class="form-control">
										<option value="<?php echo $stat; ?>"><?php echo $status_title; ?></option>
										<?php
											$get_status = "select * from status";
											$run_status = mysqli_query($con, $get_status);
											while($row = mysqli_fetch_array($run_status))
											{
												$id = $row['id'];
												$status_title = $row['title'];
												echo "<option value='$id' > $status_title  </option>";
											}
										?>
									</select>
								</div>
							</div>


							<div class="form-group">
								<label class="col-md-2 control-label"  style="text-align: left">
									Picture
								</label>
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>

								<div class="col-md-9">
									<input type="file" name="product_image" class="form-control" required="">
									<br>
									<img src = "product_images/<?php echo $p_image; ?>"  width="60" height = "40"; >
								</div>
							</div>
					
					
							<div class="form-group">
								<label class="col-md-2 control-label"  style="text-align: left">
									Price :
								</label> 
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>
								<div class="col-md-9">
									<input type="text" name="product_price" class="form-control" required="" value="<?php echo $p_price ?>">
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-2 control-label"  style="text-align: left">
									Units
								</label>
								<label class="col-md-1 control-label " style="text-align: left">
									: 
								</label>
								<div class="col-md-9">
									<input type="text" name="product_desc" class="form-control" required="" value="<?php echo $p_desc ?>">
								</div>
							</div>
					<div class="form-group">
						<label class="col-md-3 control-label"></label>

							<input type="submit" name="update" value="Update Product" class="btn-primary form-control">

					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
</div>

</body>
</html>


<?php
	if(isset($_POST['update']))
	{
		$product_title = $_POST['product_title'];
		$cat = $_POST['cat'];
		$status = $_POST['status'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		$product_image = $_FILES['product_image']['name'];
		$temp_name = $_FILES['product_image']['tmp_name'];

		move_uploaded_file($temp_name, "product_images/$product_image");

		$update_product = "update products set  c_id='$cat', s_id='$status', product_name='$product_title', product_image='$product_image', product_price='$product_price', product_desc='$product_desc' where product_id='$p_id'";

		$run_product = mysqli_query($con, $update_product);

		if($run_product)
		{
			echo "<script>alert('Product has been updated Successfully')</script>";
			echo "<script>window.open('admin.php?view_product','_self')</script>";
		}
	}
}
?>

<?php } ?>
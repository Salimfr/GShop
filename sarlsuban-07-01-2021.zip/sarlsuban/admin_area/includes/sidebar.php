<?php

	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{


?>

<nav class="navbar-inverse navbar-fixed-top" style="background:black" >
	<div class="navbar-header">

		<button type="button" class="navbar-toggle" datqa-toggle="collapse" data-target=".navbar-ex1-collapse">
			<span class="sr-only">
				Toggle Navigation
			</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a href="index.php?dashboard" class="navbar-brand">Admin Panel</a>
	</div>
	<ul class="nav navbar-right top-nav" style="padding: 0 15px">
		<li class="dropdown" style ="display: inline-block; float:left">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="padding-top: 15px; padding-bottom: 15px; line-height: 20px">
				<i class="fa fa-user"></i>
				<?php echo $admin_name ?>   
			</a>
			<ul class="dropdown-menu">
				<li>
					<a href="index.php?view_product">
						<i class="fa fa-fw-envelope"></i>
							Products
							<span class="badge">
								<?php echo $count_pro
								?>
							</span>
					</a>
				</li>
				<li>
					<a href="index.php?view_categories">
						<i class="fa fa-fw-users"></i>
						Categories
						<span class="badge">
								<?php echo $count_cat
								?>
							</span>
					</a>
				</li>
				<li>
					<a href="index.php?view_slider">
						<i class="fa fa-fw-gear"></i>
						Slider
						<span class="badge">
								<?php echo $count_slider
								?>
							</span>
					</a>
				</li>
				<li class="divider">
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-fw fa-power-off"></i>
						Logout
					</a>
				</li>
			</ul>
		</li>
	</ul>
	
</nav>

<div class="sidenav" style="width:200px; margin-left: -20px; margin-top : 0px;">

		<ul class="nav navbar-nav side-nav">
			<li>
				<a href="index.php?dashboard">
					<i class="fa fa-fw fa-dashboard"></i>
					Dashboard
				</a>
			</li>
			<li>
				<a href = "#" data-toggle="collapse" data-target = "#products">
					<i class="fa fa-fw fa-table"></i>
					Product
					<i class="fa fa-fw fa-caret-down"></i>
				</a>
			
				<ul class="collapse" id="products">
					<li>
						<a href="index.php?insert_product">Insert Product
						</a>
					</li>
					<li>
						<a href="index.php?view_product">View Product
						</a>
					</li>
				</ul>
			</li>
			
			<li>
				<a href = "#" data-toggle="collapse" data-target = "#categories">
					<i class="fa fa-fw fa-table"></i>
					Categories
					<i class="fa fa-fw fa-caret-down"></i>
				</a>
			
				<ul class="collapse" id="categories">
					<li>
						<a href="index.php?insert_categories">Insert Categories
						</a>
					</li>
					<li>
						<a href="index.php?view_categories">View Categories
						</a>
					</li>
				</ul>
			</li>
			<li>
				<a href = "#" data-toggle="collapse" data-target = "#slider">
					<i class="fa fa-fw fa-table"></i>
					Slider
					<i class="fa fa-fw fa-caret-down"></i>
				</a>
			
				<ul class="collapse" id="slider">
					<li>
						<a href="index.php?insert_slider">Insert Slider
						</a>
					</li>
					<li>
						<a href="index.php?view_slider">View Slider
						</a>
					</li>
				</ul>
			</li>
			
				</ul>
			</li>
		</ul>
	</div>

	<?php } ?>
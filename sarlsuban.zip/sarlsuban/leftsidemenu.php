<div class="list-group sidemenu mt-5">

        <button  type="submit" class="mt-5 btn btn-light promobtn text-left mb-3" onclick="window.location='promotion.php'">
          <i class="fas fa-star text-warning mr-1"></i>

          Promotions

        </button>

        <button class="btn btn-light btn-lg categorybuttons  text-left pl-3 w-100 mb-3 href="#submenu1" onclick="window.location='newarrivals.php'"
               data-toggle="collapse" data-target="#submenu1"><i class="fas fa-truck-loading text-primary mr-1"></i> Nouveautés</button>

        <button class="btn btn-light btn-lg categorybuttons  text-left pl-3 w-100 collapsed" href="#submenu1" onclick="window.location='index.php'"
               data-toggle="collapse" data-target="#submenu1"><i class="fas fa-shopping-basket mr-1 text-primary"></i> Tous les produits</button>

      </div>
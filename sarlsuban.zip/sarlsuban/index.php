<?php
  session_start();
  include("includes/db.php");
  include("functions/functions.php");

  include("includes/functions1.php");
?>
<!-- body -->
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sarl Suban</title><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/style.css">

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">

</head>

<body>
<script>
      window.addEventListener('scroll',(e)=>{
        const nav = document.querySelector('.nav');
        if(window.pageYOffset>0){
          nav.classList.add("add-shadow");
        }else{
          nav.classList.remove("add-shadow");
        }
      });
    </script>


  <nav class="navbar navbar-expand-lg navbar-light nav fixed-top">
  <a class="navbar-brand logo" href="#">Sarl Suban</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mx-auto">
      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="index.php">Home <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="promotion.php">Promotion <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="newarrivals.php">New Arrivals <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="paymentmode.php">Payment Mode <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="contactus.php">Contact Us <span class="sr-only"></span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <button class="btn btn-outline-success  my-2 my-sm-0" type="submit"><i class="fas fa-phone-volume"></i> 0169431959</button>
    </form>
  </div>
</nav>

  <div class="container-fluid">


  <div class="row">
    <!-- filter -->
    <div class="col-lg-2 mx-auto leftbar d-none d-md-block" >
      <div class="list-group sidemenu mt-5">

        <button  type="submit" class="mt-5 btn btn-light promobtn text-left mb-3">
          <i class="fas fa-star text-warning mr-1"></i>

          Promotions

        </button>

        <button class="btn btn-light btn-lg categorybuttons  text-left pl-3 w-100 mb-3 href="#submenu1"
               data-toggle="collapse" data-target="#submenu1"><i class="fas fa-carrot mr-1 text-primary"></i> New Arrivals</button>

        <button class="btn btn-light btn-lg categorybuttons  text-left pl-3 w-100 collapsed" href="#submenu1"
               data-toggle="collapse" data-target="#submenu1"><i class="fas fa-carrot mr-1 text-primary"></i> All Products</button>

      </div>
    </div>

    <!-- all products -->
    <div id='products' class="col-lg-8 mx-auto mt-4 mr-3">



      <div class="row">
        <h6 class="col mainheading ml-5 mb-3">Tous Les Produits</h6>

        <input class="col-4 form-control collapse width searchbar  ml-5 mb-2" id="myInput" onkeyup="myFunction()" type="search" placeholder="Cherchez un produit!">
        <h6 class="col-1 d-none d-md-block"><button data-toggle="collapse" data-target="#myInput" class="btn searchbutton float-right mr-3"><i class="fas fa-search"></i></button></h6>

      </div>


      <div class="row mx-auto pl-1 pr-1 mt-4" >
        <?php 
          getPro();
        ?>

        <!--
        {% for product in products %}
        <div class="card mx-auto mb-4 productcards" id="cardid"  style="width: 19rem;">
          <img class="card-img-top cardimg" src="{{product.image.url}}" alt="Card image cap">

          <div class="card-body ">

            <p class="card-title text-center productname mt-1">{{product.name}}</p>
            <div class="row pt-2">
              <p class="col-6 text-success instocktext">En Stock</p>
              <p class="col-6 card-text text-right pricetext"><b>{{product.price|currency}}</b> / kg</p>

            </div>


            {% if product|is_in_cart:request.session.cart %}
            <div class="row no-gutters">
              <form action="/#{{product.id}}" class="col-2 " method="post">
                {% csrf_token %}
                <input hidden type="text" name='product' value='{{product.id}}'>
                <input hidden type="text" name='remove' value='True'>
                <input type="submit" value=" - " class="smallcartbtns btn btn-block btn-light border-right">
              </form>

              <div class="text-center col mt-2">{{product|cart_quantity:request.session.cart}} in Cart</div>

              <form action="/#{{product.id}}" class="col-2 " method="post">
                {% csrf_token %}
                <input hidden type="text" name='product' value='{{product.id}}'>
                <input type="submit" value=" + " class="smallcartbtns btn btn-block btn-light border-left">
              </form>
              <form action="/#{{product.id}}" method="POST" class="col-4 ml-2 btn-block">
              {% csrf_token %}
                <input hidden type="text" name='product' value='{{product.id}}'>
                <input type="submit" class="float-right btn btn-light addtocart form-control "
                  value="Valider">
              </form>
            </div>
            {% else %}
            <form action="/#{{product.id}}" method="POST" class=" btn-block">
              {% csrf_token %}
              <input hidden type="text" name='product' value='{{product.id}}'>
              <input type="submit" class="float-right btn btn-light addtocart form-control "
                value="Ajouter Au Panier">
            </form>
            {% endif %}


          </div>


          </div>
        {% endfor %} 
        -->

      </div>
    </div>

    <div class="col-lg-2 mx-auto leftbar" >
      <div class="list-group mt-5">
        <div class="card mt-5" style="margin-top: 20px;">
               <div class="card-body sidebarcard text-center" style=" padding-top: 10px;">
                  <h6 class="sidebar-heading mx-auto  text-muted sidebarcontent">
                    <span>Contact Us <i class="fas fa-fire"></i></span>
                  </h6>

                  <div class="text-center shopinfotext pt-2">23-25 Av. George Sand
                    91130 - Ris-Orangis
                    sarlsuban@yahoo.fr</div>

               </div>
              </div>
      </div>

      <div class="iframe-container mt-3">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10543.83605096725!2d2.4097627!3d48.6488993!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1d5e0a05c81d57cb!2sSuban%20Alimentation%20G%C3%A9n%C3%A9rale%201!5e0!3m2!1sen!2sfr!4v1610065857071!5m2!1sen!2sfr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      
    </div>
  </div>
  </div>
</body>

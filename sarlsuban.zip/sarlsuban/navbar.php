<nav class="navbar navbar-expand-lg navbar-light nav fixed-top">
  <a class="navbar-brand logo" href="#">Sarl Suban</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mx-auto">
      <li class="nav-item active mx-1">
        <a class="nav-link topbuttons" href="index.php">Accueil <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-2">
        <a class="nav-link topbuttons" href="promotion.php">Promotion <span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-2">
        <a class="nav-link topbuttons" href="newarrivals.php">Nouveautés<span class="sr-only"></span></a>
      </li>

      <li class="nav-item active mx-2">
        <a class="nav-link topbuttons" href="contactus.php">Nous contacter <span class="sr-only"></span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <button class="btn btn-outline-success  my-2 my-sm-0" type="submit"><i class="fas fa-phone-volume"></i> 0169431959</button>
    </form>
  </div>
</nav>
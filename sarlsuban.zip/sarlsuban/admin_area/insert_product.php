<?php


	include("includes/db.php");
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>
		<!DOCTYPE html>
		<html>
			<head>
				<title>
					Insert Product
				</title>
				<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  				<script>tinymc.init({selector:'textarea'});
				</script>
			</head>
			<body>

				<div class="row">
					<div class="col-lg-10">
						<div class="breadcrumb">
							<li class="active">
								<i class="fa fa-dashboard"></i>
								Dashboard / Insert Product
							</li>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-10">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 panel-title>
									<i class="fa a-money fa-w"></i>
									Insert Product
								</h3>
							</div>
							<div class="panel-body">
								<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Product Name 
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											: 
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_title" class="form-control" required="">
										</div>
									</div>
					
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Categories
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											:
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="cat" class="form-control"   style="text-align: left">
												<option>Select a category</option>
												<?php
													$get_cats = "select * from categories";
													$run_cats = mysqli_query($con, $get_cats);
													while($row = mysqli_fetch_array($run_cats))
													{
														$id = $row['cat_id'];
														$cat_title = $row['cat_title'];
														echo "<option value = '$id' > $cat_title  </option>";
													}
												?>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Status
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											:
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="status" class="form-control"   style="text-align: left">
												<option>Select a status</option>
												<?php
													$get_status = "select * from status";
													$run_status = mysqli_query($con, $get_status);
													while($row = mysqli_fetch_array($run_status))
													{
														$id = $row['id'];
														$status_title = $row['title'];
														echo "<option value = '$id' > $status_title  </option>";
													}
												?>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Picture
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											:
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="file" name="product_image" class="form-control" required="">
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Price
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											:
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_price" class="form-control" required="">
										</div>
									</div>

					
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Units
										</label>
										<label class="col-md-1 control-label"  style="text-align: left">
											:
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_desc" class="form-control" required="">
										</div>
									</div>

									<div class="form-group">
										<input type="submit" name="submit" value="Insert Product" class=" btn-primary form-control">
									</div>

								</form>
							</div>
						</div>
					</div>
				</div>
			</body>
		</html>


<?php
	if(isset($_POST['submit']))
	{
		$product_title = $_POST['product_title'];
		$cat = $_POST['cat'];
		$status = $_POST['status'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		$product_detail = $_POST['status'];

		$product_image = $_FILES['product_image']['name'];
		$temp_name = $_FILES['product_image']['tmp_name'];

		move_uploaded_file($temp_name, "product_images/$product_image");

		$inset_product = "insert into products(c_id, s_id, product_name, product_price, product_desc, product_detail,  product_image) values ('$cat', '$status', '$product_title', '$product_price', '$product_desc', '$status', '$product_image')";

		$run_product = mysqli_query($con, $inset_product);

		if($run_product)
		{
			echo "<script>alert('Product Inserted Successfully')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
		else
		{
			echo "<script>alert('Product Not Inserted')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
	}
?>

<?php } ?>
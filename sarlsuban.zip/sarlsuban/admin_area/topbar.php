
<nav class="navbar-inverse navbar-fixed-top" style="background:black" >
  <div class="row">
    
    <div class="col-md-4">
      <a href="admin.php?dashboard" class="navbar-brand">Admin </a>
    </div>
    
    <div class="col-md-4" style="color: white; font-size: 24px;">
      SARL Suban Alimentation Generale
    </div>
    
    <div class="col-md-4">
      <ul>
    <li class="dropdown" style ="display: inline-block; float:right">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="padding-top: 15px; padding-bottom: 15px; line-height: 20px">
        <i class="fa fa-user"></i>
        <?php echo $admin_name ?>   
      </a>
      <ul class="dropdown-menu">
        <li>
          <a href="admin.php?view_product" class="afirst">
            <i class="fa fa-fw-envelope"></i>
              Products
              <span class="badge">
                <?php echo $count_pro
                ?>
              </span>
          </a>
        </li>
        <li>
          <a href="admin.php?view_categories">
            <i class="fa fa-fw-users"></i>
            Categories
            <span class="badge">
                <?php echo $count_cat
                ?>
              </span>
          </a>
        </li>
        <li>
          <a href="admin.php?view_slider">
            <i class="fa fa-fw-gear"></i>
            Slider
            <span class="badge">
                <?php echo $count_slider
                ?>
              </span>
          </a>
        </li>

        <li>
          <a href="logout.php">
            <i class="fa fa-fw fa-power-off"></i>
            Logout
          </a>
        </li>
      </ul>
    </li>
  </ul>
    </div>

</nav>

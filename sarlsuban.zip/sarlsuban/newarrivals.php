<?php
  session_start();
  include("includes/db.php");
  include("functions/functions.php");

  include("includes/functions1.php");
?>
<!-- body -->
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sarl Suban</title><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/style.css">

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">

</head>

<body>
<script>
      window.addEventListener('scroll',(e)=>{
        const nav = document.querySelector('.nav');
        if(window.pageYOffset>0){
          nav.classList.add("add-shadow");
        }else{
          nav.classList.remove("add-shadow");
        }
      });



      function myFunction() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = document.getElementsByClassName('card-body');

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByClassName("card-title")[0];

    if (a.innerText.toUpperCase().indexOf(filter) > -1) {
      li[i].parentNode.style.display = "";
    } else {
      li[i].parentNode.style.display = "none";
    }
  }
}
    </script>


 <?php include_once("navbar.php"); ?>

  <div class="container-fluid">


  <div class="row">
    <!-- filter -->
    <div class="col-lg-2 mx-auto leftbar d-none d-md-block" >
      <?php include_once("leftsidemenu.php"); ?>
    </div>

    <!-- all products -->
    <div id='products' class="col-lg-8 mx-auto mt-4 mr-3">



      <div class="row">
        <h6 class="col mainheading ml-5 mb-3">Nouveaux produits</h6>

        <input class="col-4 form-control collapse width searchbar mr-3 mb-3" id="myInput" onkeyup="myFunction()" type="search" placeholder="Cherchez un produit!">

        <h6 class="col-1 d-none d-md-block"><button data-toggle="collapse" data-target="#myInput" class="btn searchbutton float-right mr-3"><i class="fas fa-search"></i></button></h6>

      </div>


      <div class="row mx-auto pl-1 pr-1 mt-4" >
        <?php 
          getPro("newarrivals");
        ?>

      </div>
    </div>

    <div class="col-lg-2 mx-auto leftbar" >
      <div class="list-group mt-5">
        <div class="card sidebarcard mt-5" style="margin-top: 20px;">
               <div class="card-body  text-center" style=" padding-top: 10px;">
                  <h6 class="sidebar-heading mx-auto  text-muted sidebarcontent">
                    <span>Notre boutiqe <i class="fas fa-store"></i></span>
                  </h6>

                  <div class="text-center shopinfotext pt-2"> 7J/7
  9H00 à 23H30 <div class="text-primary">23-25 Avenue George Sand
                    91130  Ris-Orangis</div></div>

               </div>
              </div>
      </div>

      <div class="iframe-container mapcontainer mt-3">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10543.83605096725!2d2.4097627!3d48.6488993!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1d5e0a05c81d57cb!2sSuban%20Alimentation%20G%C3%A9n%C3%A9rale%201!5e0!3m2!1sen!2sfr!4v1610065857071!5m2!1sen!2sfr" width="600" height="450"  frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      
    </div>
  </div>
  </div>

<div class="mt-3">
  <?php
    include("includes/footer.php");
  ?>
</div>
</body>

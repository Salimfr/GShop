<footer class="bg-primary text-white text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mt-2 mb-2 mb-md-0">
        <h5 class="text-uppercase">Sarl Suban: Qui sommes nous? <i class="fas fa-store"></i></h5>

        <p>
          Sarl Suban est un magasin d'alimentation générale situé à Ris-Orangis et nous fournissons les meilleurs produits de qualité depuis 12 ans. N'hésitez pas à nous rendre visite dans notre boutique, et vous pouvez vous attendre au meilleur service client ainsi qu'aux produits.
        </p>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-3 col-md-6 mb-2 mb-md-0 mt-2">
        <h5 class="text-uppercase">Modes de Paiement <i class="far fa-credit-card"></i></h5>

        <ul class="list-unstyled mb-0 mt-3">
          <li>
            <a href="#!" class="text-white">Espèce</a>
          </li>
          <li>
            <a href="#!" class="text-white">Carte Bancaire</a>
          </li>
          <li>
            <a href="#!" class="text-white">Ticket Restaurant Accepté</a>
          </li>
        </ul>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-3 col-md-6 mb-0 mt-2">
        <h5 class="text-uppercase mb-0">Notre addresse <i class="fas fa-map-marker-alt"></i></h5>

        <ul class="list-unstyled">
          <div class="mt-3">
          			Ouvert 7J/7 9H00 à 23H30
          			<br />23-25 Avenue George Sand
                    <br />91130  Ris-Orangis
          </div>
        </ul>
      </div>
      <!--Grid column-->
    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2021 Création site par:
    <a class="text-white" href="https://bienachat.com/">BienAchat.com</a>
    (+33 6 99 82 24 96)
  </div>
  <!-- Copyright -->
</footer>
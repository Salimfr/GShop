<?php

$con = mysqli_connect("localhost","root","","3704116_sarlsuban");

?>
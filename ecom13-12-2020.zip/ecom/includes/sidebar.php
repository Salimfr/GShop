<div class="panel panel-default sidebar-menu">
	<div class="panel-heading">
		<h3 class="panel-title">Product Categories</h3>
	</div>

	<div class="panel-body">
		<ul class="nav nav-pills nav-stacked category-menu">
			<li>
				<a href="shop.php">Jackets</a>
				<a href="shop.php">Accessories</a>
				<a href="shop.php">Shoes</a>
				<a href="shop.php">Coats</a>
				<a href="shop.php">T-Shirts</a>
			</li>
		</ul>
	</div>
</div>

<div class="panel panel-default sidebar-menu">
	<div class="panel-heading">
		<h3 class="panel-title">Categories</h3>
	</div>
	<div class="panel-body">
		<ul class="nav nav-pills nav-stacked category-menu">
			<li>
				<a href="shop.php">Men</a>
				<a href="shop.php">Woman</a>
				<a href="shop.php">Kids</a>
				<a href="shop.php">Others</a>
			</li>
		</ul>
	</div>
</div>
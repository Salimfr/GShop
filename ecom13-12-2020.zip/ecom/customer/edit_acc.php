<div class="box">
	<center>
		<h1>Edit Your Account</h1>
	</center>
	<div class="form-group">
		<label>Customer Name</label>
		<input type="text" name="c_name" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Email</label>
		<input type="text" name="c_email" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Password</label>
		<input type="password" name="c_password" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Country</label>
		<input type="text" name="c_country" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer City</label>
		<input type="text" name="c_city" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Contact Number</label>
		<input type="text" name="c_number" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Address</label>
		<input type="text" name="c_address" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Customer Image</label>
		<input type="file" name="c_image" class="form-control" required="">
		<img src="customer_images/product1.jpg" class="img-resposive" height="100px" width="100px">
	</div>
	<div class="text-center">
		<button class="btn btn-primary" name="update">
			Update
		</button>
	</div>
</div>
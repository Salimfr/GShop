<?php
	//$con=mysqli_connect('fdb30.awardspace.net','3720994_restaurantindienganesh','Zishansaheen123@','3720994_restaurantindienganesh');

	$db1 = mysqli_connect('localhost','root','','makeweb');

	function getUserIP()
	{
		switch (true) 
		{
			case (!empty($_SERVER['HTTP_X_REAL_IP'])) : return $_SERVER['HTTP_X_REAL_IP'];
			case (!empty($_SERVER['HTTP_CLIENT_IP'])) : return $_SERVER['HTTP_CLIENT_IP'];
			case (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) : return $_SERVER['HTTP_X_FORWARDED_FOR'];

			default : return $_SERVER['REMOTE_ADDR'];
		}
	}

	function getPro($input)
	{
		global $con;

		$get_detail = "veg";

		if($input == "tout")
		{
			$get_product = "select * from products order by 1 ASC ";

		}

		if($input == "indien")
		{
			$get_product = "select * from products where c_id = '22' order by 1 ASC ";

		}
		if($input == "tacos")
		{
			$get_product = "select * from products where c_id = '23' order by 1 ASC ";
			
		}
		if($input == "crepe")
		{
			$get_product = "select * from products where c_id = '24' order by 1 ASC ";
			
		}
		if($input == "veg")
		{
			$get_product = "select * from products where type = 'veg' order by 1 ASC ";
			
		}
		if($input == "nonveg")
		{
			$get_product = "select * from products where type = 'non-veg' order by 1 ASC ";
			
		}
		if($input == "aboutus")
		{
			echo
			" 
        		<div class='about-us-area pt-50 pb-100'>
            		<div class='container'>
                		<div class='row'>
                    		<div class='col-lg-12 col-md-7 d-flex align-items-center'>
                        		<div class='overview-content-2'>
                            		<h2>Welcome To <span>Restaurant Indien Ganesh</span>!</h2>
         						</div>
                    		</div>
       					</div>
            		</div>
        		</div>
        	";
			
		}
		elseif($input == "contactus")
		{
			echo 
			"
				<div class='row'>
                    <div class='col-lg-4 col-md-6 col-12'>
                        <div class='contact-info-wrapper text-center mb-30'>
                            <div class='contact-info-icon'>
                                <i class='ion-ios-location-outline'></i>
                            </div>
                            <div class='contact-info-content'>
                                <h4>Our Location</h4>
                                <p>20 - 22 Avenue George Sand,</p>
                              <p>91130 Ris-Orangis</p>
                            </div>
                        </div>
                    </div>
                    <div class='col-lg-4 col-md-6 col-12'>
                        <div class='contact-info-wrapper text-center mb-30'>
                            <div class='contact-info-icon'>
                                <i class='ion-ios-telephone-outline'></i>
                            </div>
                            <div class='contact-info-content'>
                                <h4>Contact us Anytime</h4>
                                <p>06 - 45 67 51 26</p>
                                <p>06 - 30 21 54 08</p>
                            </div>
                        </div>
                    </div>
                    <div class='col-lg-4 col-md-6 col-12'>
                        <div class='contact-info-wrapper text-center mb-30'>
                            <div class='contact-info-icon'>
                                <i class='ion-ios-email-outline'></i>
                            </div>
                            <div class='contact-info-content'>
                                <h4>Write Some Words</h4>
                                <p><a href='#''>restaurantindienganesh@gmail.com</a></p>
                               <p><a href='#'>ravi@gmail.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>
			";
		}
		else
		{
		$run_products = mysqli_query($con, $get_product);
		while ($row_product = mysqli_fetch_array($run_products))
		{
			$pro_id = $row_product['product_id'];
			$pro_name = $row_product['product_name'];
			$pro_price = $row_product['product_price'];
			$pro_img1 = $row_product['product_image'];
			$pro_desc = $row_product['product_desc'];
			$pro_stat = $row_product['s_id'];
			$pro_detail = $row_product['product_detail'];
			$type = $row_product['type'];
			if($type == 'veg')
			{
				$st="Veg";
				$co = "green";
			}
			else
			{
				$st="Non Veg";
				$co = "red";
			}
			echo 
			"
				<div class='card mx-auto mb-4 productcards' id='cardid'>
					<img class='card-img-top cardimg' src='admin_area/product_images/check/$pro_img1'  alt='Card image cap'>
					<div class='card-body d-flex flex-column'>
						<p class='card-title text-center productname mt-md-1'>
							$pro_name
						</p>
						<div class='row pt-md-2 mt-auto'>
							<div class='col-md-6 order-sm-12' >
								<a class='card-text text-md-right pricetext'>
								<b>€ $pro_price</b> </a>
							</div>	
							<div class='col-md-6 order-sm-1'>
								<a style='color:$co'>$st</a>
							</div>
						</div>
					</div>
				</div>
			";
		}}
	}
?>

<header class="header_section" id="navtop">
  <div class="container">
    <nav class="navbar navbar-expand-lg custom_nav-container  fixed-top nav">
      <a class="navbar-brand pl-2" href="index.php">
        <h4>07 - 69 43 33 12 / 06 - 99 82 24 96</h4>
      </a>

      <button class="navbar-toggler mr-2" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class=""> </span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav  ml-auto">
          
          <li class="nav-item">
            <a class="nav-link navbuttons underline" href="#" onclick="window.location='admin_area/makeweb.php'">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link navbuttons underline" href="index.php?checkout">Checkout</a>
          </li> 
        </ul>
      </div>
    </nav>
  </div>
</header>
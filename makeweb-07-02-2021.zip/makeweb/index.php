<?php

  include("includes/db.php");
  
  include("functions/functions.php");

?>
<!-- body -->
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/animate.css">
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/ionicons.min.css">
  <link rel="stylesheet" href="assets/css/magnific-popup.css">
  <link rel="stylesheet" href="assets/css/simple-line-icons.css">
  <link rel="stylesheet" href="assets/css/meanmenu.min.css">
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="assets/css/slick.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="assets/css/responsive.css">
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> 
  <title>
    MakeWeb
  </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
</head>
<body>
  <script>
    window.addEventListener('scroll',(e)=>
    {
      const nav = document.querySelector('.nav');
      if(window.pageYOffset>0)
      {
        nav.classList.add("add-shadow");
      }
      else
      {
        nav.classList.remove("add-shadow");
      }
    });
    function myFunction() 
    {
      var input, filter, ul, li, a, i, txtValue;
      input = document.getElementById('myInput');
      filter = input.value.toUpperCase();
      ul = document.getElementById("myUL");
      li = document.getElementsByClassName('card-body');
      // Loop through all list items, and hide those who don't match the search query
      for (i = 0; i < li.length; i++) 
      {
        a = li[i].getElementsByClassName("card-title")[0];
        if (a.innerText.toUpperCase().indexOf(filter) > -1) 
        {
          li[i].parentNode.style.display = "";
        } 
        else 
        {
          li[i].parentNode.style.display = "none";
        }
      } 
    }
  </script>
  <div class="container-fluid">
    <div class="row">
      <?php include_once("navbar.php"); ?>
    </div>
    
    <div class="row">
      <?php 

              //SERVER Query string is the value after ? in the URL that we pass when we click the sidebar buttons to navigate !!!!
              $PageType = $_SERVER['QUERY_STRING'];  

              if($PageType == ""){ //First time into website has no string after ? in URL
                include("includes/home.php");
              }
               if($PageType == "login"){ // When Promotion button is clicked
                include("admin_area/makeweb.php");
              }
              if($PageType == "home"){ // When Promotion button is clicked
                include("includes/home.php");
              }
               if($PageType == "offer"){ // When Promotion button is clicked
                include("includes/offer.php");
              }

              if($PageType == "extras"){ // When Promotion button is clicked
                include("includes/extras.php");
              }
              if($PageType == "work"){
                include("includes/work.php");
              }
              
              if($PageType == "contact"){
                include("includes/contactus.php");
              }
              if($PageType == "started1"){
                echo "Started 1";
              }
              if($PageType == "started2"){
                echo "Started 2";
              }
              if($PageType == "started3"){
                echo "Started 3";
              }
              

              ?>

              
            </div>
            
          </div>
          <br>
  <br>
  <br>
          <div>
              <?php
                include("footer.php");
              ?>
            </div>
<script src="assets/js/vendor/jquery-1.12.0.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/imagesloaded.pkgd.min.js"></script>
        <script src="assets/js/isotope.pkgd.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>
</body>
<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li ><a href="#" onclick="window.location='index.php?home'">Home</a></li>
    
    <li><a href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li><a href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li class="active "><a class="bg-primary text-white" href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li><a href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>

<div class="container">
	<br>
	<br>
	<div class="row">
		<div class="col-sm-4">
			<img id = "img1" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img2" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img3" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
	</div>
	<br>
	<br>
	<div class="row">
		<div class="col-sm-4">
			<img id = "img1" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img2" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img3" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
	</div>
	<br>
	<br>
	<div class="row">
		<div class="col-sm-4">
			<img id = "img1" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img2" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
		<div class="col-sm-4">
			<img id = "img3" src = "assets/img/work/ecommerce.jpg" width="300">
		</div>
	</div>
</div>
<script type ="text/JavaScript">
	let image1 = document.getElementById("img1");
	let image2 = document.getElementById("img2");
	let image3 = document.getElementById("img3");
	image1.onmouseover=function()
	{
		image1.src='assets/img/work/ecommerceup.jpg'
		image1.width='300'
	}
	image1.onmouseout=function()
	{
		image1.src='assets/img/work/ecommerce.jpg'
		image1.width='300'
	}
	image2.onmouseover=function()
	{
		image2.src='assets/img/work/ecommerceup.jpg'
		image2.width='300'
	}
	image2.onmouseout=function()
	{
		image2.src='assets/img/work/ecommerce.jpg'
		image2.width='300'
	}
	image3.onmouseover=function()
	{
		image3.src='assets/img/work/ecommerceup.jpg'
		image3.width='300'
	}
	image3.onmouseout=function()
	{
		image3.src='assets/img/work/ecommerce.jpg'
		image3.width='300'
	}
</script>

<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li class="active "><a class="bg-primary text-white" href="#" onclick="window.location='index.php?home'">Home</a></li>

    <li><a href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li><a href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li><a href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li><a href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>


<?php
	echo
	" <br>
	<br>
	<br>
<div id='carouselExampleCaptions' class='carousel slide' data-ride='carousel'>
  <ol class='carousel-indicators'>
    <li data-target='#carouselExampleCaptions' data-slide-to='0' class='active'></li>
    <li data-target='#carouselExampleCaptions' data-slide-to='1'></li>
    <li data-target='#carouselExampleCaptions' data-slide-to='2'></li>
  </ol>
  <div class='carousel-inner'>
    <div class='carousel-item active'>
      <img src='assets/img/banner/bn1.jpg' class='d-block w-100' alt=''>
      <div class='carousel-caption d-none d-md-block'>
        <h5>E-Commerce Websites</h5>
        </div>
    </div>
    <div class='carousel-item'>
      <img src='assets/img/banner/bn2.jpg' class='d-block w-100' alt='...'>
      <div class='carousel-caption d-none d-md-block'>
      <h5>Dynamic Websites</h5>
        </div>
    </div>
    <div class='carousel-item'>
      <img src='assets/img/banner/bn3.jpg' class='d-block w-100' alt='...'>
      <div class='carousel-caption d-none d-md-block'>
        <h5>Logiciel</h5>
        </div>
    </div>
  </div>
  <a class='carousel-control-prev' href='#carouselExampleCaptions' role='button' data-slide='prev'>
    <span class='carousel-control-prev-icon' aria-hidden='true'></span>
    <span class='sr-only'>Previous</span>
  </a>
  <a class='carousel-control-next' href='#carouselExampleCaptions' role='button' data-slide='next'>
    <span class='carousel-control-next-icon' aria-hidden='true'></span>
    <span class='sr-only'>Next</span>
  </a>
</div>
<br>
	<br>
	<br>
	<div class='container'>
	<br>
	<br>
	<br>
		<div class='row'>
		  	<h2>
		    	Ce qui rend votre site Web sur MakeWeb spécial
			</h2>
  		</div>
		<br>
		<br>
		<br>
		<div class='row'>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Créez votre propre Site Web!
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Dans uelques semaines, vous aurez un site web professionel et moderne, à un prix trés abordable!
  				</h4>
  				<br>
  				<h4 class='card-text align-left' >
  				Il vous suffit de choisir entre deux choix:
  				</h4>
			</div>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Site Web Statique
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Le meilleux moyen de mettre est valeur votre entreprise, les sites Web statiques vous aident à augmenter votre visibilité sur le marché et peuvent attirer vous clients vers votre marque simples, modernes et efficaces, ils sont trés rentables!
  				
			</div>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Site Web pour E-Commerce
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Voulez-vous vendre vos produits en ligne? La création de sites Web de E-cimmerce vous permet de vendre vos produits ou services en ligne, de maniére sécurisée et pratique. Ceci est trés important dans le contexte du COVID-19
  				</h4>
  				
			</div>

		</div>
		<br>
		<br>
		<br>
		<div class='row'>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Ou voulez-vous un Logicel?
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Nous pouvons créer pour vous des applications et des outils à utiliser dans votre entreprise.
  				</h4>
  				<br>
  				<h4 class='card-text align-left' >
  				ex: Systéme de facturation des produits des produits, outils de communication, etc...
  				</h4>
			</div>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Conception Graphique
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Des Brouchures, des effiches ou des menus, nous pouvons créer pour vous toutes les conceptions graphiques, afin de vous aider à attirer vos clients!
  				</h4>
  				
			</div>
			<div class='col-sm-4'>
				<div class='card-header bg-warning'>
				  	<h4>
				    	Créez un nouveau logo!
					</h4>
  				</div>
  				<br>
  				<h4 class='card-text align-left' >
  				Un logo est important, il aide à créer une marque pour votre entreprise. Nous pouvons créer pour vous un logo moderne et unique reflétant vos produits et services.
  				</h4>
  				
			</div>

		</div>
		<br>
		<br>
		<br>
		
	</div>
";
?>
<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li ><a href="#" onclick="window.location='index.php?home'">Home</a></li>
    
    <li><a href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li class="active"><a class="bg-primary text-white" href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li><a href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li><a href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>

<?php
	echo
	"
		<div class='container'>
			<div class='row'>
				<br>
				<br>
				<br>
				We are specialized in
				<br>
				<br>
				<br>
				Graphic Designing
				<br>
				<br>
				
				Android App Development
				<br>
				<br>
				
				Software Development
				<br>
				<br>
				
				POS software
			</div>
		</div>
	";
?>
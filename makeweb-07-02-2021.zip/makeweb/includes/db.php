<?php

$con=mysqli_connect('localhost','root','','makeweb');
//$con=mysqli_connect('fdb28.awardspace.net','3730402_makeweb','Zishansaheen123@','3730402_makeweb');

?>
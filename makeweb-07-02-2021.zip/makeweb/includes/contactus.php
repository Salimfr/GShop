<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li ><a href="#" onclick="window.location='index.php?home'">Home</a></li>
    
    <li><a href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li><a href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li><a href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li class="active "><a class="bg-primary text-white" href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>

<?php    
    echo 
	"

        <div class='container'>
            <br>
            <br>
            <br>
    		<div class='row'>
                <div class='col-lg-4 col-md-6 col-12'>
                    <div class='contact-info-wrapper text-center mb-30'>
                        <div class='contact-info-icon'>
                            <i class='ion-ios-location-outline'></i>
                        </div>
                        <div class='contact-info-content'>
                            <h4>Our Location</h4>
                            <p>8 Rue Henri Matisse,</p>
                          <p>91100 Corbeil Essonnes</p>
                        </div>
                    </div>
                </div>
                <div class='col-lg-4 col-md-6 col-12'>
                    <div class='contact-info-wrapper text-center mb-30'>
                        <div class='contact-info-icon'>
                            <i class='ion-ios-telephone-outline'></i>
                        </div>
                        <div class='contact-info-content'>
                            <h4>Contact us Anytime</h4>
                            <p>06 - 99 82 24 96</p>
                            <p>07 - 69 43 33 12</p>
                        </div>
                    </div>
                </div>
                <div class='col-lg-4 col-md-6 col-12'>
                    <div class='contact-info-wrapper text-center mb-30'>
                        <div class='contact-info-icon'>
                            <i class='ion-ios-email-outline'></i>
                        </div>
                        <div class='contact-info-content'>
                            <h4>Write Some Words</h4>
                            <p><a href='#''>salimfr1975@yahoo.fr</a></p>
                            <p><a href='#''>zishan@makeweb.fr</a></p>
                            <p><a href='#''>contact@makeweb.fr</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	";
?>
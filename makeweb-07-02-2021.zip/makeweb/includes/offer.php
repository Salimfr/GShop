
<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li ><a href="#" onclick="window.location='index.php?home'">Home</a></li>
    
    <li class="active"><a class="bg-primary text-white" href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li><a href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li><a href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li><a href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>


<div class="container">
<br>
	<br>
	<br>
<div class="row">
  <div class="col-sm-4">
<div class="card text-center">

  <div class="card-header bg-primary ">
  	<h2>
    	Started
	</h2>
  </div>
  <div class="card-body">
  	<hr>
    <h5 class="card-title">$49 / month + $ 399 sign-up</h5>
    <hr>
    <p class="card-text ">We'll build upto 5 pages</p>
    <hr>
    <p class="card-text">Standard Blog</p>
    <hr>
    <p class="card-text">Fully Managed Turnkey Website</p>
    <hr>
    <p class="card-text">Weekly Website Report</p>
    <hr>
    <p class="card-text">100% Satisfation Guaranteed</p>
    <hr>
    <p class="card-text">Unlimited Minor Updates</p>
    <hr>
    <p class="card-text">Unlimited Staff Account</p>
    <hr>
    <p class="card-text">Fast Hosting + SSL ( $ 35 / m value! )</p>
    <hr>
    <p class="card-text">Free Private Domain ( $12/y value! )</p>
    <hr>
    <p class="card-text">10 Free Stock Photos ( $ 10 value! )</p>
    <hr>
    <p class="card-text">Email & Live Chat Support</p>
    <hr>
    <p class="card-text">1 Week Delivery</p>
    <hr>
    <p class="card-text">No Hidden Fees</p>
    <hr>
  </div>
  <div class="card-footer bg-warning  text-muted">
  	<h2>
   		Get Started
   	</h2>
  </div>
</div>
</div>
<div class="col-sm-4">
<div class="card text-center">
  <div class="card-header bg-primary ">
  	<h2>
    	Premium
	</h2>
  </div>
  <div class="card-body">
  	<hr>
    <h5 class="card-title">$49 / month + $ 599 sign-up</h5>
    <hr>
    <p class="card-text ">We'll build upto 15 pages</p>
    <hr>
    <p class="card-text">Standard Blog</p>
    <hr>
    <p class="card-text">Fully Managed Turnkey Website</p>
    <hr>
    <p class="card-text">Weekly Website Report ($ 20 / m value! </p>
    <hr>
    <p class="card-text">100% Satisfation Guaranteed</p>
    <hr>
    <p class="card-text">Unlimited Minor Updates</p>
    <hr>
    <p class="card-text">Unlimited Staff Account</p>
    <hr>
    <p class="card-text">Fast Hosting + SSL ( $ 35 / m value! )</p>
    <hr>
    <p class="card-text">Free Private Domain ( $12/y value! )</p>
    <hr>
    <p class="card-text">30 Free Stock Photos ( $ 30 value! )</p>
    <hr>
    <p class="card-text">Email & Live Chat Support</p>
    <hr>
    <p class="card-text">1 Week Delivery</p>
    <hr>
    <p class="card-text">No Hidden Fees</p>
    <hr>
  </div>
  <div class="card-footer bg-warning  text-muted">
  	<h2>
   		Get Premium
   	</h2>
  </div>
</div>
</div>
<div class="col-sm-4">
<div class="card text-center">
  <div class="card-header bg-primary ">
  	<h2>
    	eCommerce
	</h2>
  </div>
  <div class="card-body">
  	<hr>
    <h5 class="card-title">$69 / month + $ 899 sign-up</h5>
    <hr>
    <p class="card-text ">We'll build upto 5 pages</p>
    <hr>
    <p class="card-text ">We'll build upto 10 Products / Variations</p>
    <hr>
    <p class="card-text">Unlimited Products / Variations</p>
    <hr>
    <p class="card-text">Unlimited Stock Accounts</p>
    <hr>
    <p class="card-text">Discount Codes </p>
    <hr>
    <p class="card-text">WooCommerce Services</p>
    <hr>
    <p class="card-text">Standard Blog</p>
    <hr>
    <p class="card-text">Fully Managed Turnkey Website</p>
    <hr>
    <p class="card-text">Weekly Website Report ( $ 20 / m value!)</p>
    <hr>
    <p class="card-text">100% Satisfaction Guaranteed</p>
    <hr>
    <p class="card-text">Unlimited Minor Updates</p>
    <hr>
    <p class="card-text">Fast Hosting + SSL ( $ 35 / m value!)</p>
    <hr>
    <p class="card-text">Free Private Domain ( $12/y value! )</p>
    <hr>
    <p class="card-text">10 Free Stock Photos ( $ 10 value! )</p>
    <hr>
    <p class="card-text">Email & Live Chat Support</p>
    <hr>
    <p class="card-text">2 Week Delivery</p>
    <hr>
    <p class="card-text">No Hidden Fees</p>
    <hr>
  </div>
  <div class="card-footer bg-warning  text-muted">
  	<h2>
   		Get eCommerce
   	</h2>
  </div>
</div>
</div>


</div>
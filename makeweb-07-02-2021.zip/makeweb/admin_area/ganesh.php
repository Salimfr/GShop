<?php
	session_start();
	include("includes/db.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Bien Achat</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/login.css">
	<link rel="stylesheet" href="login.css">

	<title>Alimentation Ganesh</title><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/style.css">

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		
	</script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body>

	<div class="container">

		<div class="card mx-auto mt-5" style="max-width: 400px; border-radius: 12%;">
			<h5 class="card-title text-center mt-3 welcometext">Mon Espace Personnel</h5>
            <form class="cardleftside mx-4" action="" method="post">
                           <div class="form-group pt-3 ">
                              <label for="exampleInputEmail1" class="desctext">Votre Adresse Email</label>
                              <input type="email" name="admin_email"  class="form-control loginbuttons" id="email"  aria-describedby="emailHelp" placeholder="Enter email">
                           </div>
                           <div class="form-group pt-2">
                              <label for="exampleInputEmail1" class="desctext">Mot de Passe</label>
                              <input type="password" name="admin_pass" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password">
                           </div>
                           <div class="text-center pt-3">
                              <button onclick="login()" class=" btn btn-block loginbtn btn-primary tx-tfm" name="admin_login">Login</button>
                           </div>

                           <div class="">
                              <div class="login-or">
                                 <hr class="hr-or">
                              </div>
                           </div>

                           <div class="form-group">
                            <p  class="undertexts text-center">Mot de passe oublié ? <a href="../index.php" id="signup">Obtenir un nouveau</a></p>
                            <p  class="undertexts text-center">Retourner au page principale? <a href="../index.php" id="signup">Cliquer ici</a></p>
                           </div>
                        </form>
		</div>
	</div>
</body>

</html>

<?php
	if(isset($_POST['admin_login']))
	{
		$admin_email = mysqli_real_escape_string($con, $_POST['admin_email']);

		$admin_pass = mysqli_real_escape_string($con, $_POST['admin_pass']);

		$get_admin= "select * from admins where admin_email='$admin_email' AND admin_pass = '$admin_pass'";
		$run_admin = mysqli_query($con, $get_admin);
		$count = mysqli_num_rows($run_admin);
		if($count==1)
		{
			$_SESSION['admin_email'] = $admin_email;
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
		else
		{
			echo "<script>alert('Email ou Mot de Passe erronnée')</script>";
		}
	}

?>
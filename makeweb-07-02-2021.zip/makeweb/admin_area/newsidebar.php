
  <nav class="sidebar">
    <div class="text">
      <?php echo $admin_name ?>
    </div>
    <ul>
      <li>
        <a href="index.php?dashboard">
          Dashboard
        </a>
      </li>
      <li>
        <a href="#" class="feat-btn first">
          Product
          <span class="fas fa-caret-down"></span>
        </a>
        <ul class="feat-show">
          <li>
            <a href="admin.php?insert_product">
              Insert Product
            </a>
          </li>
          <li>
            <a href="admin.php?view_product">
              View Product
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a href="#" class="serv-btn second">
          Categories
          <span class="fas fa-caret-down"></span>
        </a>
        <ul class="serv-show">
          <li>
            <a href="admin.php?insert_categories">
              Insert Categories
            </a>
          </li>
          <li>
            <a href="admin.php?view_categories">
              View Categories
            </a>
          </li>
        </ul>
      </li> 

      <li>
        <a href="#" class="slid-btn third">
          Slider
          <span class="fas fa-caret-down"></span>
        </a>
        <ul class="slid-show">
          <li>
            <a href="admin.php?insert_slider">
              Insert Slider
            </a>
          </li>
          <li>
            <a href="admin.php?view_slider">
              View Slider
            </a>
          </li>
        </ul>
      </li>  

      
      

      <li>
        <a href="logout.php" class="logout-btn fifth">
          <i class="fa fa-fw fa-power-off"></i>
          Logout
        </a>
      </li>               
    </ul>
  </nav>
  <script>

    $('.btn').click(function()
    {
      $(this).toggleClass("click");
      $('.sidebar').toggleClass("show");
    });

    $('.feat-btn').click(function()
    {
      $('nav ul .feat-show').toggleClass("show");
      $('nav ul .first').toggleClass("rotate");
    });

    $('.serv-btn').click(function()
    {
      $('nav ul .serv-show').toggleClass("show1");
      $('nav ul .second').toggleClass("rotate");
    });

    $('.slid-btn').click(function()
    {
      $('nav ul .slid-show').toggleClass("show2");
      $('nav ul .third').toggleClass("rotate");
    });

    $('.user1-btn').click(function()
    {
      $('nav ul .user1-show').toggleClass("show3");
      $('nav ul .fourth').toggleClass("rotate");
    });

    $('nav ul li').click(function()
    {
      $(this).addClass("active").siblings().removeClass("active");
    });

    $('btn').click(function() {
      $(this).toggleClass("click");
    });

  </script>

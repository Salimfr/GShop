<?php

	if(!isset($_SESSION['admin_email']))
	{

		echo "<script>window.open('ganesh.php','_self')</script>";
	}
	else
	{

?>
<?php
	if(isset($_GET['delete_slide']))
	{

		$delete_id=$_GET['delete_slide'];
		$delete_slider1 = "delete from slider where id='$delete_id'";
		$run_delete=mysqli_query($con, $delete_slider1);
		if($run_delete)
		{
			echo "<script>alert('One Slide has been Deleted')</script>";
			echo "<script>window.open('admin.php?view_slider','_self')</script>";
		}
		else
		{

		}
	}
?>
<?php } ?>
<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('ganesh.php','_self')</script>";
	}
	else
	{
?>

	<div class="row">
		<div class="col-lg-12">
			<ol class="breadcrumb">
				<li class="active">
					<i class="fa fa-dashboard">
					</i>
					Dashboard / Products
				</li>
			</ol>
		</div>		
	</div>

	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">
						<i class="fa fa-money fa-fw"></i>
						<a class="btn btn-primary" href="admin.php?insert_product">
						Ajouter un produit
					</a>
					</h3>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-bordered table-hover table-striped">
							<thead>
								<tr>
									<th>
										Id
									</th>
									<th>
										Image
									</th>
									<th>
										Nom
									</th>
									
									<th>
										Prix
									</th>
									<th>
										Supprimer
									</th>
									<th>
										Modifier
									</th>
                                                                        <th>
										Stock
									</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$i=0;
									$get_product="select * from products";
									$run_p=mysqli_query($con, $get_product);
									while($row=mysqli_fetch_array($run_p))
									{
										$pro_id=$row['product_id'];
										$product_name=$row['product_name'];
										$product_status=$row['s_id'];
										$product_img1=$row['product_image'];
										$product_price=$row['product_price'];
										$product_desc=$row['product_desc'];
										$product_detail=$row['product_detail'];
										$i++;

								?>
									
										<tr>

											<?php if($product_status==1) :?>
											<td style="color:white; background-color: orange"><?php echo $i ?></td>

											<?php elseif($product_status==2) :?>
												<td style="color:white; background-color: green"><?php echo $i ?></td>
											<?php else  :?>
												<td style="color:white; background-color: green"><?php echo $i ?></td>

												<?php endif; ?>
											<td><img src="../assets/img/product/<?php echo $product_img1 ?>" width="60" height="40"></td>


											<td><?php echo $product_name ?>
												
											</td>
											<td><?php echo $product_price ?>  <?php echo $product_desc ?></td>
								

																						

											<td>
												<a class= "btn btn-outline-danger" href="admin.php?delete_product=<?php echo $pro_id ?>">
													
													Supprimer
												</a>
											</td>
											<td>
												<a class= "btn btn-outline-info" href="admin.php?edit_product=<?php echo $pro_id ?>">
													
													Modifier
												</a>
											</td>
                                                                                        <?php if($product_detail==1) :?>
                                                                                        <td>
												<a class= "btn btn-success" href="admin.php?active_product=<?php echo $pro_id ?>">
													
													Finish
												</a>
											</td>
                                                                                        <?php else  :?>
                                                                                        <td>
												<a class= "btn btn-danger" href="admin.php?deactive_product=<?php echo $pro_id ?>">
													
													Stock
												</a>
											</td>
                                                                                        <?php endif; ?>
										</tr>
										<?php } ?>
							</tbody>
						</table>	
					</div>
				</div>
			</div>
		</div>
		
	</div>

<?php } ?>
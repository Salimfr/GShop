<?php

	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('ganesh.php','_self')</script>";
	}
	else
	{


?>

<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Dashboard
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-dashboard"></i>
				Dashboard
			</li>
		</ol>
	</div>
</div>
<div class="row">
	<div class="col-md-9">
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-tasks fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 40px; line-height: normal">
									<?php echo $count_pro ?>
								</div>
								<div>
									Products
								</div>
							</div>
						</div>	
					</div>
					<a href="admin.php?view_product">
						<div class="panel-footer">.
							<span class="pull-left">
								View Details
							</span>
							<span class="pull-right">
								<i class="fa fa-arrow-circle-right">
								</i>
							</span>
							<div class="clearfx">
								
							</div>
						</div>
					</a>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="panel panel-red"  style = "color: #fff; background-color: #d9534f">
					<div class="panel-heading"  style = "color: #fff; background-color: #d9534f">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-shopping-cart fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 40px; line-height: normal">
									<?php echo $count_cat ?>
								</div>
								<div>
									Categories
								</div>
							</div>
						</div>	
					</div>
					<a href="admin.php?view_categories"  style = "color: #d9534f">
						<div class="panel-footer">.
							<span class="pull-left">
								View Details
							</span>
							<span class="pull-right">
								<i class="fa fa-arrow-circle-right">
								</i>
							</span>
							<div class="clearfx">
								
							</div>
						</div>
					</a>
				</div>
			</div>

			<div class="col-md-4">
				<div class="panel panel-yellow"  style = "color: #fff; background-color: #f0ad4e">
					<div class="panel-heading" style = "color: #fff; background-color: #f0ad4e">
						<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-support fa-5x"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge" style="font-size: 40px; line-height: normal">
									<?php echo $count_slider ?>
								</div>
								<div>
									Slider
								</div>
							</div>
						</div>	
					</div>
					<a href="admin.php?view_slider"  style = "color: #f0ad4e">
						<div class="panel-footer">.
							<span class="pull-left">
								View Details
							</span>
							<span class="pull-right">
								<i class="fa fa-arrow-circle-right">
								</i>
							</span>
							<div class="clearfx">
								
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">
							<i class="fa fa-money fa-fw"></i>
							New Products
						</h3>
					</div>
					<div class="table-responsive">
						<table class="table table-bordered table-hover table-striped">
							<thead>
								<tr>
									<th>
										No
									</th>
									<th>
										Image
									</th>
									<th>
										Name
									</th>
									<th>
										Price
									</th>
									<th>
										Unit
									</th>
									<th>
										Category 
									</th>
								</tr>
							</thead>
							<tbody>

								<?php
									$i=0;
									$get_product = "select * from products where s_id = 2";
									$run_product = mysqli_query($con, $get_product);
									while($row_product=mysqli_fetch_array($run_product))
									{
										$cat = $row_product['c_id'];
										$product_name = $row_product['product_name'];
										$product_image = $row_product['product_image'];
										$product_price = $row_product['product_price'];
										$product_desc = $row_product['product_desc'];
										$i++;
								?>
								<tr>
									<td>
										<?php echo $i ?>
									</td>
									<td><img src="product_images/check/<?php echo $product_image ?>" width="60" height="40"></td>
									<td><?php echo $product_name ?></td>
									<td><?php echo $product_price ?></td>
									<td><?php echo $product_desc ?></td>
									<td>
										

										<?php
										
											$get_cat = "select * from categories where cat_id = $cat";
											$run_cat = mysqli_query($con, $get_cat);
											while($row_cat=mysqli_fetch_array($run_cat))
											{
												$cat_title = $row_cat['cat_title'];
											}
										?>
										<?php echo $cat_title ?>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>

					</div>
					
				</div>

				
			</div>
		</div>

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-danger">
					<div class="panel-heading">
						<h3 class="panel-title">
							<i class="fa fa-money fa-fw"></i>
							Promotions
						</h3>
					</div>
					<div class="table-responsive">
						<table class="table table-bordered table-hover table-striped">
							<thead>
								<tr>
									<th>
										No
									</th>
									<th>
										Image
									</th>
									<th>
										Name
									</th>
									<th>
										Price
									</th>
									<th>
										Unit
									</th>
									<th>
										Category 
									</th>
								</tr>
							</thead>
							<tbody>

								<?php
									$i=0;
									$get_product = "select * from products where s_id = 1";
									$run_product = mysqli_query($con, $get_product);
									while($row_product=mysqli_fetch_array($run_product))
									{
										$cat = $row_product['c_id'];
										$product_name = $row_product['product_name'];
										$product_image = $row_product['product_image'];
										$product_price = $row_product['product_price'];
										$product_desc = $row_product['product_desc'];
										$i++;
								?>
								<tr>
									<td>
										<?php echo $i ?>
									</td>
									<td><img src="product_images/check/<?php echo $product_image ?>" width="60" height="40"></td>
									<td><?php echo $product_name ?></td>
									<td><?php echo $product_price ?></td>
									<td><?php echo $product_desc ?></td>
									<td>
										

										<?php
										
											$get_cat = "select * from categories where cat_id = $cat";
											$run_cat = mysqli_query($con, $get_cat);
											while($row_cat=mysqli_fetch_array($run_cat))
											{
												$cat_title = $row_cat['cat_title'];
											}
										?>
										<?php echo $cat_title ?>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>

					</div>
					
				</div>

				
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel">
			<div class="panel-body">
				<div class="thumb-info mb-md">
					<img src="admin-images/<?php echo $admin_image ?>" class="rounded img-responsive">
					<div class="thumb-info-title">
						
						<span class="thumb-info-inner">
							<?php echo $admin_name ?>
						</span>
						<span class="thumb-info-type">
							<?php echo $admin_job ?>
						</span>
					</div>
				</div>
				<div class="mb-md">
					<div class="widget-content-expanded">
						<i class="fa fa-user"></i>
						<span>
							Email :
						</span>
						<?php echo $admin_email ?> <br>
						<i class="fa fa-user"></i>
						<span>
							Country :
						</span>
						<?php echo $admin_country ?> <br>
						<i class="fa fa-user"></i>
						<span>
							Contact :
						</span>
						<?php echo $admin_contact ?> <br>
					</div>
					<hr class="dotted short">
					<h5 class = "text-muted">
						About
					</h5>
					<p>
						<?php echo $admin_about ?>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>

<?php } ?>
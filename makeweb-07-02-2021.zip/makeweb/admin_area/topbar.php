<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Restaurant Indien Ganesh</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">

      <li class="nav-item active">
        <a class="nav-link" href="admin.php?view_product">Dish<span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="admin.php?view_categories">Catégories</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="admin.php?view_slider">Slider</a>
      </li>

      

    </ul>
    
  </div>

<div class="nav navbar-nav navbar-right" id="navbarNav">
    <ul class="navbar-nav">
      
      <li class="nav-item">
        <a class="nav-link" href="../index.php">Me déconnecter</a>
        
      </li>

    </ul>
  </div>

</nav>
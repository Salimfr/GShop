<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('ganesh.php','_self')</script>";
	}
	else
	{
?>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title mt-3">
							<i class="fa fa-money fa-fw"></i>
							Ajouter une catégorie
						</h3>	
					</div>	
					<div class="panel-body">
						<form class="form-horizontal" action="" method="post">
							<div class="form-group">
								<label class="col-md-3 control-label mt-3">
									Nom
								</label>	
								<div class="col-md-6">
									<input type="text" name="cat_title" class="form-control">	
								</div>	
							</div> 
							<div class="form-group">
								<label class="col-md-3 control-label">	
								</label>	
								<div class="col-md-6">
									<input type="submit" name="submit" value="Ajouter" class=" btn-primary form-control">
								</div>
							</div>
						</form>	
					</div>
				</div>	
			</div>	
		</div>
<?php
	if(isset($_POST['submit']))
	{
		$cat_title = $_POST['cat_title'];
		$insert_cat = "insert into categories(cat_title) values('$cat_title')";
		$run_p_cat = mysqli_query($con, $insert_cat);
		if($run_p_cat)
		{
			echo "<script>alert('New  Category has been Inserted')</script>";
			echo "<script>window.open('admin.php?view_categories','_self')</script>";
		}
	}
?>
<?php } ?>


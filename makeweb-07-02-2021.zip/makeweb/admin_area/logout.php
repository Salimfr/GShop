<?php
	session_start();
	session_destroy();
	echo "<script>window.open('../includes/home.php','_self')</script>";
?>
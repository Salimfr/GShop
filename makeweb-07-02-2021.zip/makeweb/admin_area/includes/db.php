<?php

$con=mysqli_connect('localhost','root','','makeweb');
//$con=mysqli_connect('fdb30.awardspace.net','3720994_restaurantindienganesh','Zishansaheen123@','3720994_restaurantindienganesh');
?>

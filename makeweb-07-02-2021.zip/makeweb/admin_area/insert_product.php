<?php


	include("includes/db.php");
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('ganesh.php','_self')</script>";
	}
	else
	{
?>
		<!DOCTYPE html>
		<html>
			<head>
				<title>
					Insert Product
				</title>
				<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  				<script>tinymc.init({selector:'textarea'});
				</script>
			</head>
			<body>


				<div class="container">
					<div class="col-lg-12">
						<div class="panel panel-default pt-3">
							<div class="panel-heading">
								<h3 panel-title>
									<i class="fa a-money fa-w"></i>
									Ajouter un Dish
								</h3>
							</div>
							<div class="panel-body">
								<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Nom de Dish 
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="text" name="product_name" class="form-control" required="">
										</div>
									</div>
					
									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Catégorie
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="cat" class="form-control"   style="text-align: left">
												<option>Choisir une catégorie</option>
												<?php
													$get_cats = "select * from categories";
													$run_cats = mysqli_query($con, $get_cats);
													while($row = mysqli_fetch_array($run_cats))
													{
														$id = $row['cat_id'];
														$cat_title = $row['cat_title'];
														echo "<option value = '$id' > $cat_title  </option>";
													}
												?>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"  style="text-align: left">
											Type de Produit
										</label>
										<div class="col-md-9"  style="text-align: left">
											<select name="type" class="form-control"   style="text-align: left">
												<option>Choisir le type</option>
												<option>Veg</option>
												<option>Non-Veg</option>
												
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Ajouter une image
										</label>
										<div class="col-md-9"  style="text-align: left">
											<input type="file" name="product_image" class="form-control" required="">
										</div>
									</div>

									<div class="form-group">
										<label class="col-md-2 control-label"   style="text-align: left">
											Prix
										</label>
										<div class="col-md-9 "  style="text-align: left">
											<input type="text" name="product_price" class="form-control" required="">
										</div>
									</div>

					
									

									<div class="form-group" >
										<input class="col-md-9 bg-primary " type="submit" name="submit" value="Ajouter le produit" class=" btn-primary form-control">
									</div>

								</form>
							</div>
						</div>
					</div>
				</div>
			</body>
		</html>


<?php
	if(isset($_POST['submit']))
	{
		$product_name = $_POST['product_name'];
		$cat = $_POST['cat'];
		$status = $_POST['status'];
		$product_price = $_POST['product_price'];
		$product_desc = $_POST['product_desc'];
		$product_detail = $_POST['status'];
		$type = $_POST['type'];

		$product_image = $_FILES['product_image']['name'];
		$temp_name = $_FILES['product_image']['tmp_name'];

		move_uploaded_file($temp_name, "../assets/img/product/$product_image");

		$inset_product = "insert into products(c_id, s_id, product_name, product_price, product_desc, product_detail,  product_image, type) values ('$cat', '$status', '$product_name', '$product_price', '$product_desc', '1', '$product_image','$type')";

		$run_product = mysqli_query($con, $inset_product);

		if($run_product)
		{
			echo "<script>alert('Product Inserted Successfully')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
		else
		{
			echo "<script>alert('Product Not Inserted')</script>";
			echo "<script>window.open('admin.php?view_product', '_self')</script>";
		}
	}
?>

<?php } ?>
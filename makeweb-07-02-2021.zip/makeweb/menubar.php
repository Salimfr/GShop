<div class="container">
  <h2>MakeWeb</h2>
  <ul class="nav nav-tabs">
    <li class="active "><a class="bg-primary" href="#" onclick="window.location='index.php?home'">Home</a></li>
   /* <li class="dropdown">
      <a class="dropdown-toggle" data-toggle="dropdown" href="#">Get Started </a>
      <ul class="dropdown-menu">
        <li><a href="#" onclick="window.location='index.php?started1'">Submenu 1-1</a></li>
        <li><a href="#" onclick="window.location='index.php?started2'">Submenu 1-2</a></li>
        <li><a href="#" onclick="window.location='index.php?started3'">Submenu 1-3</a></li>                        
      </ul>
    </li> */
    <li><a href="#" onclick="window.location='index.php?offer'">Our Offer</a></li>
    <li><a href="#" onclick="window.location='index.php?extras'">Extras</a></li>
    <li><a href="#" onclick="window.location='index.php?work'">Our Work</a></li>
    <li><a href="#" onclick="window.location='index.php?contact'">Contact Us</a></li>
  </ul>
</div>
</div>


<div clas ="panel panel-default sidebar-menu">
	<div class="panel-heading">
		<center>
			<img src="customer_images/product1.jpg" class="img-responsive">
		</center>
		<br>
		<h3 align="center" class="panel-title">Name : Abdul</h3>
	</div>
	<div class="panel-body">
		<ul class="nav nav-pills nav-stacked">
			<li>
				<a href="my_account.php?my_order">My Order
				</a>
			</li>
		</ul>
	</div>
</div>
<?php
	$db = mysqli_connect("localhost","root","","sarlsuban");
	
	function getPro()
	{
		global $db;
		$get_product = "select * from products order by 1 DESC LIMIT 0,6";
		$run_products = mysqli_query($con, $getproduct);
		while ($row_product = mysqli_fetch_array($run_products))
		{
			$pro_id = $row_product['product_id'];
			$pro_title = $row_product['product_title'];
			$pro_price = $row_product['product_price'];
			$pro_img1 = $row_product['product_img1'];
			echo "
					<div>
						<div class='product'>
							<a href='details.php'?pro_id = $pro_id'>
							<img src ='admin_area/product_images/$pro_img1'  style='height: 190px; border-radius: 5%; border-top-right-radius: 12%; border-top-left-radius: 12%; object-fit: cover;' class='img-responsive'>
							</a>

					</div>
				";
			}
		}
	}
	function getSide()
	{
		global $db;
		$get_product = "select * from products order by 1 DESC LIMIT 0,6";
		$run_products = mysqli_query($db, $getproduct);
		while ($row_product = mysqli_fetch_array($run_products))
		{
			$pro_id = $row_product['product_id'];
			$pro_title = $row_product['product_title'];
			$pro_price = $row_product['product_price'];
			$pro_img1 = $row_product['product_img1'];
			echo "
					<div class='col-md-2 col-sm-3'>
						<div class='product'>
							<a href='details.php'?pro_id = $pro_id'>
							<img src ='admin_area/product_images/$pro_img1' class='img-responsive'>
							</a>
							<div class='text'>
								<h3>
									<a href='details.php?pro_id=$pro_id'>$pro_title</a>
								</h3>
								<p class='price'> € $pro_price</p>
							</div>
						</div>
					</div>
				";
			}
		}
	}
	function getPCats()
	{
		global $db;
		$get_p_cats = "select * from product_category";
		$run_p_cats = mysqli_query($db, $get_p_cats);
		while ($row_p_cats = mysqli_fetch_array($run_p_cats)) {
			$p_cat_id = $row_p_cats['p_cat_id'];
			$p_cat_title = $row_p_cats['p_cat_title'];
			echo "
				<li>
					<a href='shop.php?p_cat_id'>
						$p_cat_title
					</a>
				</li>
			";
		}
	}

?>

<div class="box">
	<center>
		<h3>
			Change your password
		</h3>
	</center>
	<div class="form-group">
		<label>Enter your current password</label>
		<input type="password" name="old_password" class="form-control" required="">
	</div> 
	<div class="form-group">
		<label>Enter new password</label>
		<input type="password" name="new_password" class="form-control" required="">
	</div>
	<div class="form-group">
		<label>Confirm new password</label>
		<input type="password" name="c_n_password" class="form-control" required="">
	</div>
	<div class="text-center">
		<button class="btn btn-primary btn-lg">
			Update Now
		</button>
	</div>
</div>
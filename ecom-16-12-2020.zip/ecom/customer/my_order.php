<div class="box">
	<center>
		<h1>
			My Order
		</h1>
		<p>If you have any questions, please feel free to <a href="../contactus.php">
		contact us</a>, our customer service center is working for you 24/7</p>
	</center>
	<hr>
	<div class="table-responsive">
		<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th>Sr.No</th>
				<th>Due Amount</th>
				<th>Invoice Number</th>
				<th>Quantity</th>
				<th>Size</th>
				<th>Order Date</th>
				<th>Paid/Unpaid</th>
				<th>Status</th>
			</tr>
		</thead> 
		<tbody>
			<tr>
				<td>1</td>
				<td>€ 40</td>
				<td>554541</td>
				<td>2</td>
				<td>Large</td>
				<td>2020-12-12</td>
				<td>Unpaid</td>
				<td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm if Paid </a></td>
			</tr>
			<tr>
				<td>2</td>
				<td>€ 80</td>
				<td>554542</td>
				<td>2</td>
				<td>Large</td>
				<td>2020-12-12</td>
				<td>Unpaid</td>
				<td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm if Paid </a></td>
			</tr>
			<tr>
				<td>3</td>
				<td>€ 40</td>
				<td>554543</td>
				<td>2</td>
				<td>Large</td>
				<td>2020-12-12</td>
				<td>Unpaid</td>
				<td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm if Paid </a></td>
			</tr>
			<tr>
				<td>4</td>
				<td>€ 40</td>
				<td>554544</td>
				<td>2</td>
				<td>Large</td>
				<td>2020-12-12</td>
				<td>Unpaid</td>
				<td><a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm if Paid </a></td>
			</tr>
		</tbody>
		</table>
	</div>
</div>
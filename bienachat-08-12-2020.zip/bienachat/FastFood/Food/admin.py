from django.contrib import admin
from .models import Pizza
from .models import Burger

# Register your models here.

class AdminPizza(admin.ModelAdmin):
    list_display = ['name', 'priceM', 'priceL', 'pImage']


class AdminBurger(admin.ModelAdmin):
    list_display = ['name', 'priceM', 'priceL', 'bImage']




# Register your models here.
admin.site.register(Pizza, AdminPizza)

admin.site.register(Burger, AdminBurger)

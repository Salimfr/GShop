var hours = 24;
var now = new Date.getTime();
var stepTime = localStorage.getItem('stepTime');

if (stepTime == null)
{
    localStorage.setItem('stepTime',now);
}
else
{
    if (now - stepTime > hours*60*60*1000)
    {
        localStorage.clear();
        localStorage.setItem('stepTime',now);
    }
}


var orders = JSON.parse(localStorage.getItem('orders'));
var total = JSON.parse(localStorage.getItem('total'));

if (orders === null || orders === unidentified)
{
    localStorage.setItem('orders', JSON.stringify([]));
    orders =  JSON.parse(localStorage.getItem('order'));
}


if (total == null || total == unidentified)
{
    localStorage.setItem('total', 0);
    orders =  JSON.parse(localStorage.getItem('total'));
}


var cart = document.querySelector('#cart');
cart.innerHTML = orders.length;

var pcart = document.querySelector('#pcart');
var ptotal = document.querySelector('#ptotal');


function addPizza(pid)
{
    pizzaId = '#piz' + pid;
    var name = document.querySelector(pizzaId).innerHTML;
    var radio = 'pizza' + pid;
    var pri = document.getElementsByName(radio);
    var size=0, price;

    pcart.innerHTML = 'abc';

}

function addPizz(pid)
{

    pcart.innerHTML = 'abc';

}
<?php
	session_start();
	include("includes/db.php");
	include("functions/functions.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bien Achat</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="styles/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
		
	</script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body>
	<div id="top">
		<div class="container">
			<div class="col-md-3 offer">
				
				<a href="#" class="btn btn-success btn-sm">
					06-99 82 24 96
				</a>
			</div>
			<div class="col-md-6  offer">
				<h4>
					SARL SUBAN Alimentation Generale
				</h4>
			</div>
			<div class="col-md-3 offer">
	
			</div>
			
		</div>
	</div>
	<div class="navbar navbar-default" id="navbar">
		<div class="container">
			<div class="navbar-header">			
					<a class="navbar-brand home" href="newarrivals.php">
						New Arrivals
					</a>		
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
						<span class="sr-only">Toggle Navigation</span>
						<i class="fa fa-align-justify">
							
						</i>
					</button>
					<button type="button" class="navbar-toggle" data-toggle="navbar-toggle" data-target="#search">
						<span class="sr-only"></span>
						<i class="fa fa-search">
							
						</i>
					</button>
				
			</div>
			<div class="navbar-collapse collapse" id="navigation">
				<div class="padding-nav">
					<ul class="nav navbar-nav navbar-left">
						<li>
							<a href="index.php">Home</a>
						</li>
						<li>
							<a href="promotion.php">Promotion</a>
						</li>
						
						<li class="active">
							<a href="newarrivals.php">New Arrivals</a>
						</li>
						<li>
							<a href="paymentmode.php">Payment Mode</a>
						</li>
						<li>
							<a href="contactus.php">Contact Us</a>
						</li>
					</ul>
				</div>				
			</div>
		</div>
	</div>
	<div class="container" id="slider">
		<div class="col-md-12">
			<div class="carousel slide" id="myCarousel" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="myCarousel" data-slide-to="1"></li>
					<li data-target="myCarousel" data-slide-to="2"></li>
					<li data-target="myCarousel" data-slide-to="3"></li>
				</ol>
				<div class="carousel-inner">
					<?php
						$get_slider = "select * from slider LIMIT 0,1";
						$run_slider = mysqli_query($con, $get_slider);
						while ($row=mysqli_fetch_array($run_slider))
						{
							$slider_name = $row['slider_name'];
							$slider_image = $row['slider_image'];
							echo "<div class='item active'>
							<img src = 'admin_area/slider_images/$slider_image'>
							</div>
							";
						} 
					?>
					<?php
						$get_slider = "select * from slider LIMIT 1,100";
						$run_slider = mysqli_query($con, $get_slider);
						while ($row=mysqli_fetch_array($run_slider))
						{
							$slider_name = $row['slider_name'];
							$slider_image = $row['slider_image'];
							echo "<div class='item'>
							<img src = 'admin_area/slider_images/$slider_image'>
							</div>
							";
						} 
					?>
					
				</div>
				<a href="#myCarousel" class="left carousel-control" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a href="#myCarousel" class="right carousel-control" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
	<div id="content" class="container">
		<div class="row">
			<div class="col-lg-10">
				<?php
					getProNew();
				?>
			</div>
			<div class="col-lg-2">
				<?php
					getSide();
				?>
			</div>
		</div>
	</div>
	<?php
		include("includes/footer.php");
	?>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
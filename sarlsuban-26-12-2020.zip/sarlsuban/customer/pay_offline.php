<div class="box">
	<center>
		<h1>
			Pay Offline Using below Method
		</h1>
		<p>
			If you have any questions, please feel free to
			<a href="../contactus.php">contact us</a>, 
			our customer service center is working for you 24/7
		</p>
	</center>
	<hr> 
	<div class="table-responsive">
		<table class="table table-bordered table-hover table-striped">
			<thead>
				<tr>
					<th>Bank Account Detail</th>
					<th>Paypal Id</th>
					<th>Payumoney Link</th>
					<th>PayTm Number</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>31970150027</td>
					<td>bienachat@gmail.com</td>
					<td>xxxxxxxxx</td>
					<td>9956454525</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
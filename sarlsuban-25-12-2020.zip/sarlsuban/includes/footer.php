<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-sm-6">
				<h4>Pages</h4>
				<ul>
					<li>
						<a href="../cart.php">Promotions</a>
					</li>
					<li>
						<a href="../contact.php">New Arrival</a>
					</li>
					<li>
						<a href="../shop.php">Payment Mode</a>
					</li>
					<li>
						<a href="my_account.php">Contact Us</a>
					</li>
				</ul>
				
			</div>
			<div class="col-md-3 col-sm-6">
				<h4>
					Horaires
				</h4>
				<p>
					<br>7J/7
					<br>9H00 à 23H30
					
				</p>
			</div>
			<div class="col-md-3 col-sm-6">
				<h4>
					where to find us
				</h4>
				<p>
					<strong>SARL Suban</strong>
					<br>23-25 Av. George Sand
					<br>91130 - Ris-Orangis
					<br>sarlsuban@yahoo.fr
					<br>0033-01-69 43 19 59
				</p>
			</div>
			<div class="col-md-3 col-sm-6">
				<h4>Stay in Touch</h4>
				<p class="social">
					<a href="#">
						<i class="fa fa-facebook">
						</i>
					</a>
					<a href="#">
						<i class="fa fa-twitter">
						</i>
					</a>
					<a href="#">
						<i class="fa fa-instagram">
						</i>
					</a>
					<a href="#">
						<i class="fa fa-google-plus">
						</i>
					</a>
					<a href="#">
						<i class="fa fa-envelope">
						</i>
					</a>
				</p>
			</div>
		</div>
	</div>
	
</div>
<div id="copyright">
	<div class="container">
		<div class="col-md-6">
			<p class="pull-left">
				&copy; 2020 ABDUL WAHAB Abdul Salim
			</p>
		</div>
		<div class="col-sm-6">
			<p class="pull-right">
				Template By : <a href="www.bienachat.com">www.bienachat.com
				</a>
		</div>
		</div>
	</div>
</div>
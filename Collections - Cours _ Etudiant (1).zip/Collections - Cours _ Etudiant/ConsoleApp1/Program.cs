﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;

namespace Test_Collection
{
    class MaCollection
    {

        #region MaCollection
        int[] tab;
        // Constructeur
        public MaCollection(int longueur)
        {
            tab = new int[longueur];
            Random r = new Random();
            for (int i = 0; i < tab.Length; i++)
            {
                tab[i] = r.Next(1, 10);
            }
        }

        /// <summary>
        /// Crée un clone de l'attribut tab
        /// </summary>
        /// <returns>retourne un clone de tab</returns>
        public int[] Clone()
        {
            int[] tabretour = new int[tab.Length];
            for (int i = 0; i < tab.Length; i++)
                tabretour[i] = tab[i];
            return tabretour;
        }

        /// <summary>
        /// Copie un tableau à partir d'un indice
        /// </summary>
        /// <param name="indice">indice à partir duquel on commence la copie dans tab</param>
        /// <param name="copie">le tableau à copier</param>
        public void Copie(int indice, int[] copie)
        {
            for (int i = indice; i < tab.Length; i++)
                tab[i] = copie[i - indice];
        }

        /// <summary>
        /// Insérer un élément dans un tableau
        /// </summary>
        /// <param name="val">valeur à ajouter</param>
        public void InsereTete(int val)
        {
            int[] copie = this.Clone();
            tab = new int[tab.Length + 1];
            tab[0] = val;
            this.Copie(1, copie);

        }

        public void Affiche()
        {
            for (int i = 0; i < this.tab.Length; i++)
            {
                Console.Write(this.tab[i] + "\t");
            }
            Console.WriteLine();
        }
        #endregion
        #region Création d'une méthode générique qui s'adapte à tout type       
        static void WriteType<T>(T obj)
        {
            Console.WriteLine(obj + " est de type " + typeof(T));
        }
        static void WriteType<T, U>(T tObj, U uObj)
        {
            Console.WriteLine(
                tObj + " est de type " + typeof(T) + " et " + uObj + " est de type " + typeof(U));
        }
        #endregion
        #region  exos sur Collection Non Générique  : obsolete     
        static void ExoArrayList()
        {
            #region Class Object
            object myobject0 = 6;
            object myobject1 = 6;
            if (myobject0 == myobject1) Console.WriteLine("ok"); else Console.WriteLine("non ok");

            object p1 = new Personne("Arthur", "Miller");
            object p2 = p1; // new Personne("Jp", "Belmondo");
            if (p1 == p2) Console.WriteLine("ok"); else Console.WriteLine("non ok");
            #endregion

            #region ArrayList
            ArrayList l = new ArrayList(5);
            Console.WriteLine("Capacité " + l.Capacity);
            l.Add(10);
            l.Add("10");
            l[0] = "100";
            l.Add(new Personne("Arthur", "Miller"));
            l.Insert(3, "200");

            object val_permier_element = l[1];
            Console.WriteLine("Nombre " + l.Count);
            Console.WriteLine("Capacité " + l.Capacity);
            Console.WriteLine(" Affichage des éléments de la collection ");
            foreach (object val in l) Console.WriteLine(val);
            l.Remove("100");
            for (int i = 0; i < l.Count; i++)
                Console.WriteLine(l[i]);

            #endregion
        }
        static void ExoSortedList()
        {
            SortedList st = new SortedList();
            Console.WriteLine(st.Capacity);
            st.Add(0, "toto");
            st.Add(1, 5);
            st.Add(2, 6.2f);
            for (int i = 0; i < st.Count; i++)
                Console.WriteLine(st[i]);

            SortedList st1 = new SortedList();
            st1.Add("0", "toto");
            st1.Add("1", 5);
            st1.Add("2", 6.2f);
            // for (int i = 0; i < st1.Count; i++)
            Console.WriteLine(st1["2"]);
        }
        static void ExoQueue()
        {
            Queue q0 = new Queue(5);
            q0.Enqueue("5");
            q0.Enqueue('5');
            q0.Enqueue(null);
            q0.Enqueue(new Personne("tutu", "tutu"));
            Console.WriteLine(q0.IsSynchronized);
            foreach (object val in q0) Console.Write(val + " ");
            Console.WriteLine();
            q0.Clear();
            foreach (object val in q0) Console.Write(val + " ");
            Console.WriteLine();
        }
        static void ExoStack()
        {

            Stack s0 = new Stack(5);
            s0.Push(5);
            s0.Push("5");
            s0.Push('5');
            s0.Push(new Personne("tutu", "tutu"));
            foreach (int val in s0) Console.Write(val + " ");
            Console.WriteLine();
            object valsup = s0.Pop();
            foreach (object val in s0) Console.Write(val + " ");
            Console.WriteLine();
            s0.Push("last one");
            Console.WriteLine("Le haut de la pile " + s0.Peek());
        }
        #endregion
        #region exos sur Collection  Générique
        static void ExoList()
        {
            List<int> l1 = new List<int>();
            List<string> l2 = new List<string>();
            l1.Capacity = 3;
            Console.WriteLine("Capacité : " + l1.Capacity);
            Console.WriteLine(l1.Count);


            //l1.Add(100);
            //l1[0] = 10;
            //l1[1] = 11;
            //l1.Add(101);
            //l1.Clear();
            //Console.WriteLine(l1[1]);
            l1.Add(10);
            Console.WriteLine(l1.Contains(10));
            Console.WriteLine(l1[0]);
            l1.Add(10);
            Console.WriteLine("Capacité : " + l1.Capacity);
            Console.WriteLine(l1.Count);

            //effet de bord sur le paramètre entrant 
            List<int> l3 = new List<int>();
            //l3.Add(3);
            //int[] t = { 1,1 };
            //l3.CopyTo(t);
            //foreach (int val in t) Console.Write(val + " ");
            //Console.WriteLine();    

            l1.Add(5);
            l1.Add(2);
            foreach (int val in l1) Console.Write(val + " ");
            Console.WriteLine();
            l1.Sort();
            foreach (int val in l1) Console.Write(val + " ");
            Console.WriteLine();
            l1.Insert(2, 7);
            foreach (int val in l1) Console.Write(val + " ");
            Console.WriteLine();
            l1.Insert(4, 7);
            foreach (int val in l1) Console.Write(val + " ");
            Console.WriteLine();
            List<int> l10 = l1.GetRange(2, 3);
            foreach (int val in l10) Console.Write(val + " ");
            Console.WriteLine();


            List<Personne> p = new List<Personne>();
            p.Add(new Personne("toto", "toto"));
            p.Add(new Personne("titi", "titi"));
            foreach (Personne val in p) Console.Write(val + " ");
            Console.WriteLine();
        }
        static void ExoQueue1() // First In First Out
        {
            Queue<int> s = new Queue<int>();
            s.Enqueue(4);
            object o = s.Dequeue();
            foreach (int val in s) Console.Write(val + " ");
            Console.WriteLine();

        }
        static void ExoStack1() // Last In, First Out
        {
            Stack<int> s = new Stack<int>();
            s.Push(4);
            foreach (int val in s) Console.Write(val + " ");
            Console.WriteLine();
        }
        static void ExoDictionaire()
        {
            Dictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(1, "One");
            dict.Add(2, "Two");
            dict.Add(3, "Three");
            Dictionary<int, string> dict1 = new Dictionary<int, string>()
                                            {
                                                {1,"One"},
                                                {2, "Two"},
                                                {3,"Three"}
                                            };
            Console.WriteLine("Key: {0}, Value: {1}", 1, dict1[0]);

            foreach (KeyValuePair<int, string> item in dict)
            {
                Console.WriteLine("Key: {0}, Value: {1}", item.Key, item.Value);
            }
          

            dict.ContainsKey(1);
            dict.Remove(1);
        }
        static void ExoSortedListGeneric()
        {
            SortedList<int, string> sortedList1 = new SortedList<int, string>();
            sortedList1.Add(3, "Three");
            sortedList1.Add(4, "Four");
            sortedList1.Add(1, "One");
            sortedList1.Add(5, "Five");
            sortedList1.Add(2, "Two");
            for (int i = 0; i < sortedList1.Count; i++)
            {
                Console.WriteLine("key: {0}, value: {1}", sortedList1.Keys[i], sortedList1.Values[i]);
            }

        }
        #endregion

        static void Main(string[] args)
        {

            #region 0 - Lecture/Ecriture Fichiers
            string[] lecturefichier = File.ReadAllLines("Des.txt");
            for (int i = 0; i < lecturefichier.Length; i++)
            {
                Console.WriteLine(lecturefichier[i]);
            }
            File.WriteAllLines("DesSortie1.txt", lecturefichier);

            StreamReader st = null;
            try
            {
                st = new StreamReader("Des.txt");
                string line = null;
                while ((line = st.ReadLine()) != null)
                    Console.WriteLine(line);
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }






            #endregion
            #region 1 - Limitation d'un Tableau statique
            //int[] exemple1 = { 2, 3, 4 };
            //MaCollection mc1 = new MaCollection(10);
            //Affiche(mc1);
            //mc1.InsereTete(6);
            //Affiche(mc1);
            #endregion
            #region 2 - Tests Collection non générique : obsolete

            // ExoArrayList();
            // ExoSortedList();
            // ExoStack();
            // ExoQueue();
            #endregion
            #region 3 - Généricité dans les méthodes : variable de type

            WriteType<int>(4);
            WriteType<string>("4");
            WriteType<char>('4');
            WriteType<int, string>(4, "toto");

            #endregion
            #region 4 - Généricité dans les classes
            ClasseGenerique<int> t = new ClasseGenerique<int>(4);
            t.Write();
            ClasseGenerique<string> t1 = new ClasseGenerique<string>("4");
            t1.Write();
            ClasseGenerique<char> t2 = new ClasseGenerique<char>('4');
            t2.Write();
            Voiture v = new Voiture("ABC1", "rouge", "Mercedes", "C220");
            ClasseGenerique<Voiture> t3 = new ClasseGenerique<Voiture>(v);
            t3.Write();
            #endregion
            #region 5 - Tests Collection Generique
            ExoList();
            //ExoStack1();
            //ExoQueue1();
            //ExoDictionaire();
            //ExoSortedListGeneric();
            #endregion           
            Console.ReadKey();
        }
 
    }
}

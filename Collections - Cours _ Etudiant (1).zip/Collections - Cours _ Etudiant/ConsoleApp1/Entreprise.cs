﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Collection
{
    class Entreprise
    {
        string nom;
        List<Personne> personnes;
       

        public Entreprise(string nom, List<Personne> p)
        {
            this.nom = nom;
            this.personnes = p;
            Personne p1 = new Personne("toto", "titi");
            personnes.Add(p1);
        }

    }
}

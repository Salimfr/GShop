﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Collection
{
    class Voiture
    {
        string matricule;
        string couleur;
        string marque;
        string modele;

        public Voiture(string matricule,
        string couleur,
        string marque,
        string modele)
        {
            this.matricule = matricule;
            this.couleur = couleur;
            this.marque = marque;
            this.modele = modele;
        }

        public override string ToString()
        {
            return "voiture test";

        }
    }
}

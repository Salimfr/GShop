﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Collection
{
     class Personne
    {
        string nom;
        string prenom;
        static int nb =0;


        public Personne(string nom, string prenom)
        {
            this.nom = nom;
            this.prenom = prenom;
            nb++;
        }
        public Personne(Personne p)
        {
            this.nom = p.nom;
            this.prenom = p.prenom;
            nb++;
        }

        public static int Nb
        {
            get { return nb; }
        }
        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }
        public string toString()
        {
            return nom + " " + prenom;
        }
      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Collection
{
    public class GenericList<T>
    {
        private class Node
        {          
            private T data;
            private Node next;

            public Node Next
            {
                get { return next; }
                set { next = value; }
            }
            public T Data
            {
                get { return data; }
                set { data = value; }
            }

            public Node(T t)
            {
                next = null;
                data = t;
            }
        }
        private Node head;


        public GenericList()
        {
            head = null;
        }
        public void AddHead(T t)
        {
            Node myNode = new Node(t);
            myNode.Next = head;
            head = myNode;
        }
    }
}

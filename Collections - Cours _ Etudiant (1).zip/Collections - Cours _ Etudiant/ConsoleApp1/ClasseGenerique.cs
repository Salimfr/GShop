﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Collection
{
    class ClasseGenerique<T>

    {
        T valeur;
        public ClasseGenerique (T val)
            {
            valeur = val;
            }

        public void Write()
        {
            Console.WriteLine("La valeur " + valeur.ToString() + " est du type " + typeof(T));
        }

    }
}
